import { open, signIn, nav, shot } from "./blib.mjs";
import { judge, FIX, BASE } from "./lib.mjs";
import fs from "node:fs";
const mobile = process.argv[2] === "m"; const tag = mobile ? "m" : "d";
const { browser, page, errors, context } = await open(mobile);
const c = await judge();
const count = async (q) => (await c.j("GET", "/api/documents?q=" + encodeURIComponent(q))).d.documents.filter(d => d.original_name.startsWith(q)).length;
const png = fs.readFileSync(FIX + "judge.png"), pdf = fs.readFileSync(FIX + "tag-barcode-desktop.pdf");
const stamp = Date.now() % 1000000;
await signIn(page);
const openAdd = async () => { await page.waitForTimeout(700); await page.getByRole("button", { name: "Add document", exact: true }).or(page.getByRole("button", { name: "Add", exact: true })).first().click(); };
const choose = async (files) => { const ch = page.waitForEvent("filechooser"); await page.getByRole("button", { name: /Browse files/ }).click(); await (await ch).setFiles(files); };
const banner = async () => (await page.locator("main").innerText()).split("\n").filter(l => /waiting|could not|Added|offline|upload|sent|connection|retry/i.test(l)).slice(0, 6).join(" || ");
// 1 offline
const n1 = `j3off-${tag}-${stamp}`;
await openAdd(); await context.setOffline(true);
await choose([{ name: n1 + "-a.png", mimeType: "image/png", buffer: png }, { name: n1 + "-b.pdf", mimeType: "application/pdf", buffer: pdf }]);
await page.waitForTimeout(1500); console.log("1 offline banner:", await banner()); await shot(page, `${tag}-30-offline-waiting`);
// reload while offline: does the shell load?
const rl = await page.reload({ timeout: 8000 }).then(() => "loaded").catch(e => "reload failed: " + String(e).split("\n")[0].slice(0, 80)); console.log("1 reload offline:", rl, "| title:", await page.title().catch(() => "?"));
await page.waitForTimeout(800); await shot(page, `${tag}-31-offline-reload`); console.log("  body:", (await page.locator("body").innerText().catch(() => "")).replace(/\n+/g, " | ").slice(0, 300));
await context.setOffline(false);
if (rl !== "loaded" || !(await page.locator("main").count())) { await page.goto(BASE + "/"); }
await page.waitForTimeout(600);
if (await page.getByLabel(/Username/).count()) { console.log("  (sign-in screen after offline reload)"); await signIn(page); }
await page.evaluate(() => window.dispatchEvent(new Event("online"))); await page.waitForTimeout(6000);
console.log("1 after online banner:", await banner(), "| server count:", await count(n1));
// 2 lost response
const n2 = `j3lost-${tag}-${stamp}`; let hits = 0, scanIds = [];
await page.route("**/api/documents", async (route) => { if (route.request().method() !== "POST") return route.continue(); hits++; scanIds.push(route.request().headers()["x-ripiano-scan-id"]); if (hits === 1) { await route.fetch().catch(() => {}); return route.abort("connectionreset"); } return route.continue(); });
await openAdd(); await choose([{ name: n2 + ".png", mimeType: "image/png", buffer: png }]);
await page.waitForTimeout(2500); console.log("2 lost-response banner:", await banner(), "| server count now:", await count(n2)); await shot(page, `${tag}-32-lost-response`);
const retryBtn = page.getByRole("button", { name: /Try again|Retry|Send now|Upload now/ }); console.log("  retry buttons:", await retryBtn.allInnerTexts());
await page.evaluate(() => window.dispatchEvent(new Event("online"))); await page.waitForTimeout(5000);
if (hits < 2 && await retryBtn.count()) { await retryBtn.first().click(); await page.waitForTimeout(4000); }
console.log("2 after retry: hits", hits, "same scan id:", new Set(scanIds).size === 1 && !!scanIds[0], "| server count:", await count(n2), "| banner:", await banner());
await page.unroute("**/api/documents");
// 3 proxy 503 then recovery
const n3 = `j3bad-${tag}-${stamp}`; let h3 = 0;
await page.route("**/api/documents", async (route) => { if (route.request().method() !== "POST") return route.continue(); h3++; if (h3 <= 1) return route.fulfill({ status: 503, body: "<html>503</html>", contentType: "text/html" }); return route.continue(); });
await openAdd(); await choose([{ name: n3 + ".png", mimeType: "image/png", buffer: png }]);
await page.waitForTimeout(2500); console.log("3 503 banner:", await banner()); await shot(page, `${tag}-33-503`);
await page.waitForTimeout(35000); console.log("3 after 35s (auto retry?): hits", h3, "count", await count(n3), "|", await banner());
if (await count(n3) === 0) { await page.evaluate(() => window.dispatchEvent(new Event("online"))); await page.waitForTimeout(4000); console.log("3 after online event: hits", h3, "count", await count(n3)); }
await page.unroute("**/api/documents");
// 4 session expired during upload
const n4 = `j3exp-${tag}-${stamp}`;
await openAdd(); const saved = await context.cookies(); await context.clearCookies({ name: "sessionid" });
await choose([{ name: n4 + ".png", mimeType: "image/png", buffer: png }]);
await page.waitForTimeout(2500); console.log("4 expired-session:", (await page.locator("body").innerText()).replace(/\n+/g, " | ").slice(0, 400)); await shot(page, `${tag}-34-session-expired-upload`);
if (await page.getByLabel(/Username/).count()) { await signIn(page); await page.waitForTimeout(5000); console.log("4 after sign-in again: count", await count(n4), "|", await banner()); }
// 5 sign out with pending
const n5 = `j3so-${tag}-${stamp}`;
await openAdd(); await context.setOffline(true); await choose([{ name: n5 + ".png", mimeType: "image/png", buffer: png }]); await page.waitForTimeout(1200);
if (mobile) await page.getByRole("button", { name: /menu/i }).first().click();
await page.getByRole("button", { name: "Sign out" }).click().catch(e => console.log("signout click fail")); await page.waitForTimeout(800);
console.log("5 sign-out with pending:", (await page.getByRole("dialog").innerText().catch(() => "(no dialog) " )).replace(/\n+/g, " | ").slice(0, 400)); await shot(page, `${tag}-35-signout-pending`);
await context.setOffline(false);
const discard = page.getByRole("button", { name: /Discard|Remove/ }); if (await discard.count()) { await discard.first().click(); await page.waitForTimeout(1500); }
console.log("5 after:", (await page.locator("body").innerText()).replace(/\n+/g, " | ").slice(0, 200), "| count", await count(n5));
console.log("errors", errors.filter(e => !/ERR_INTERNET_DISCONNECTED|Failed to load resource/.test(e)));
await browser.close();

import { launch, login, MOBILE, audit, ART, FIX, save } from "./common.mjs";
import { readFileSync } from "node:fs";
const b = await launch();
const p = await (await b.newContext(MOBILE)).newPage();
const log = [];
const t0 = Date.now();
await login(p, "it");
const stamp = Date.now().toString(36);
const files = [
  ["Scatta una foto", "judge.png", "image/png", `j2cam-${stamp}.png`],
  ["Scegli dalle foto", "judge.png", "image/png", `j2gal-${stamp}.png`],
  ["Sfoglia i file", "three-pages.pdf", "application/pdf", `j2pdf-${stamp}.pdf`],
  ["Sfoglia i file", "office-letter.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", `j2docx-${stamp}.docx`],
  ["Sfoglia i file", "email-notice.eml", "message/rfc822", `j2eml-${stamp}.eml`],
  ["Sfoglia i file", "outlook-notice.msg", "application/vnd.ms-outlook", `j2msg-${stamp}.msg`],
  ["Sfoglia i file", "office-sheet.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", `j2xlsx-${stamp}.xlsx`],
];
for (const [btn, fx, mime, name] of files) {
  await p.getByRole("button", { name: "Aggiungi", exact: true }).click();
  const d = p.getByRole("dialog"); await d.waitFor();
  const chooser = p.waitForEvent("filechooser");
  const resp = p.waitForResponse((r) => r.url().endsWith("/api/documents") && r.request().method() === "POST", { timeout: 30000 });
  await d.getByRole("button", { name: new RegExp("^" + btn) }).click();
  await (await chooser).setFiles({ name, mimeType: mime, buffer: readFileSync(`${FIX}/${fx}`) });
  const r = await resp;
  let body = null; try { body = await r.json(); } catch {}
  await p.waitForTimeout(1200);
  const status = await p.locator("[role=status], [role=alert]").allTextContents();
  log.push({ fx, name, http: r.status(), id: body?.id, statusText: status.filter(Boolean).slice(0, 4), dialogOpen: await d.isVisible().catch(() => false) });
  if (await d.isVisible().catch(() => false)) await d.getByRole("button", { name: "Chiudi", exact: true }).click();
}
await p.screenshot({ path: ART + "/mobile-after-uploads.png", fullPage: true });
// wait for processing
const deadline = Date.now() + 180000;
let processing = "?";
while (Date.now() < deadline) {
  await p.getByRole("button", { name: "Aggiorna" }).click().catch(() => {});
  await p.waitForTimeout(5000);
  processing = await p.evaluate(() => [...document.querySelectorAll("strong")].map(s => s.parentElement.textContent.trim()).filter(t => /In elaborazione/.test(t)).join("|"));
  if (/^0\s*In elaborazione/.test(processing)) break;
}
log.push({ processing, secs: (Date.now() - t0) / 1000 });
await p.screenshot({ path: ART + "/mobile-library-processed.png", fullPage: true });
save("library-after.yml", await p.locator("main").ariaSnapshot());
save("capture.json", { stamp, log });
console.log(JSON.stringify({ stamp, log }, null, 1));
await b.close();

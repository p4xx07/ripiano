import { launch, login, MOBILE, audit, ART, save } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext(MOBILE)).newPage();
await login(p, "it");
const s = p.getByRole("textbox", { name: /Cerca documenti/ });
for (const q of ["9473", "lampone", "Office conversion", "condominio", "mittente:Comune", "pagina"]) {
  await s.fill(q); await p.waitForTimeout(2500);
  const rows = await p.locator("article").evaluateAll(a => a.map(x => x.innerText.replace(/\s+/g," ").slice(0,160)));
  console.log("Q", q, "=>", rows.length, JSON.stringify(rows.slice(0,3)));
  const st = await p.locator("main [role=status], main [role=alert]").allInnerTexts(); console.log("  status:", st.filter(Boolean));
}
await s.fill("9473"); await p.waitForTimeout(2000);
await p.screenshot({ path: ART + "/mobile-search-ocr.png" });
await p.getByRole("button", { name: /^j2cam-/ }).click();
const d = p.getByRole("dialog"); await d.waitFor(); await p.waitForTimeout(1500);
save("doc-dialog.yml", await d.ariaSnapshot());
console.log("focus:", await p.evaluate(() => document.activeElement?.outerHTML.slice(0,120)));
console.log(await audit(p));
await p.screenshot({ path: ART + "/mobile-doc-dialog.png" });
await b.close();

import { launch, login, DESKTOP, ART } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext(DESKTOP)).newPage();
await login(p, "it");
await p.getByRole("button", { name: "Backup", exact: true }).click(); await p.waitForTimeout(2000);
console.log((await p.locator("main").innerText()).split("\n").slice(0, 30).join(" | "));
await p.screenshot({ path: ART + "/desktop-backup.png" });
await b.close();

import { createRequire } from "node:module";
import { pw, BASE } from "./lib.mjs";
import { SHOTS } from "./blib.mjs";
const require = createRequire("/Users/debotta/dbrepos/ripiano/apps/web/"); const { chromium } = require("@playwright/test");
for (const loc of ["en-US", "it-IT"]) {
  const browser = await chromium.launch({ channel: "chrome", headless: true }); const ctx = await browser.newContext({ locale: loc, viewport: { width: 1440, height: 900 } }); const page = await ctx.newPage(); page.setDefaultTimeout(7000);
  page.on("dialog", d => { console.log("DIALOG:", d.message()); d.accept(); });
  await page.goto(BASE + "/"); await page.getByLabel(/Username|Nome utente/).fill("judge3"); await page.getByLabel(/^Password/).fill(pw()); await page.getByRole("button", { name: /Sign in|Accedi/ }).click(); await page.getByRole("heading", { level: 1 }).first().waitFor();
  await page.getByRole("button", { name: /^(Tags & filing|Etichette e archiviazione)$/ }).click(); await page.waitForTimeout(800);
  await page.getByRole("button", { name: /^(Delete|Elimina) j3r3-A$/ }).click(); await page.waitForTimeout(900);
  console.log(loc, "message:", await page.locator('[role=alert]').allInnerTexts());
  await page.locator('[role=alert]').first().scrollIntoViewIfNeeded().catch(() => {});
  await page.screenshot({ path: SHOTS + `d-22-delete-filter-tag-${loc.slice(0, 2)}.png` });
  await browser.close();
}

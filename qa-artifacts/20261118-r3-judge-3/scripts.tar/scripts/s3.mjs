import fs from "node:fs";
import { judge, Client, upload, waitDoc, FIX, BASE, mcp, tool, pw, sleep } from "./lib.mjs";
const c = await judge();
const o = JSON.parse(fs.readFileSync("s2-out.json"));
const S = (x) => JSON.stringify(x).slice(0, 260);
const show = (k, r) => console.log(k.padEnd(40), r.s, S(r.d));
// ---- API tokens
show("token wrong pw", await c.j("POST", "/api/account/tokens", { name: "j3r3-t", password: "nope" }));
let r = await c.j("POST", "/api/account/tokens", { name: "j3r3-token", password: pw(), expires_in_days: 1 }); console.log("token create", r.s, Object.keys(r.d), r.d.prefix);
const tok = r.d.token, tokId = r.d.id;
const T = async (m, p, b) => { const x = await fetch(BASE + p, { method: m, headers: { Authorization: "Token " + tok, ...(b ? { "Content-Type": "application/json" } : {}) }, body: b ? JSON.stringify(b) : undefined, redirect: "manual" }); const t = await x.text(); let d; try { d = JSON.parse(t) } catch { d = t.slice(0, 120) } return { s: x.status, d }; };
show("tok GET documents", { s: (await T("GET", "/api/documents")).s, d: "" });
for (const [m, p, b] of [["GET", "/api/account/tokens"], ["POST", "/api/account/tokens", { name: "x", password: "x" }], ["GET", "/api/account/security"], ["POST", "/api/account/password", {}], ["GET", "/api/agents"], ["POST", "/api/agents", { name: "j3r3-x", scopes: ["documents:text"] }], ["GET", "/api/agents/events"], ["GET", "/api/people"], ["GET", "/api/groups"], ["GET", "/api/backups"], ["POST", "/api/backups", {}], ["GET", "/api/workflows"], ["GET", "/api/sources"], ["GET", "/api/mail"], ["POST", `/api/documents/${o.dPdf}/shares`, {}], ["GET", `/api/documents/${o.dPdf}/shares`], ["POST", `/api/documents/${o.dPdf}/access`, { user_id: 1 }], ["POST", "/api/share-bundles", {}], ["POST", `/api/documents/${o.dPdf}/email`, {}], ["GET", "/api/session"], ["DELETE", "/api/session"], ["GET", "/api/semantic-settings"], ["GET", "/api/trash-retention"], ["POST", "/api/trash-retention", {}], ["GET", "/api/browse-exports"], ["GET", "/api//account/tokens"], ["GET", "/api/documents/../account/tokens"], ["GET", "/api/account%2Ftokens"], ["GET", "/admin/"], ["GET", "/api/object-access/tag/" + o.TA], ["GET", "/api/schema.json"], ["GET", `/api/documents/${o.dPdf}/export`], ["GET", "/api/jobs"], ["GET", "/api/filing-model"], ["GET", "/api/purge-jobs"]])
  show(`tok ${m} ${p.replace(/[0-9a-f-]{36}/, ":id")}`, await T(m, p, b));
// token destructive: trash+purge own disposable doc
const s1 = JSON.parse(fs.readFileSync("s1-out.json"));
show("tok trash", await T("POST", `/api/documents/${s1.long}/trash`));
show("tok purge", await T("POST", `/api/documents/${s1.long}/purge`, { confirm: true, title: "x" }));
show("tok PATCH tag", await T("POST", "/api/tags", { name: "j3r3-bytoken" }));
// token no csrf needed + cookie mix: token header with bad token but valid session
r = await c.j("GET", "/api/documents", undefined, { Authorization: "Token rip_bad" }); show("session+bad token", { s: r.s, d: r.d.error });
show("revoke", await c.j("DELETE", "/api/account/tokens/" + tokId));
show("tok after revoke", await T("GET", "/api/documents"));
// ---- disposable user
const tpw = "Tmp-" + crypto.randomUUID(); fs.writeFileSync("tmpuser.pw", tpw);
r = await c.j("POST", "/api/people", { username: "j3r3-tmp", password: tpw, name: "J3 temp", current_password: pw() }); show("create person", r);
let uid = r.d.id ?? r.d.person?.id; if (!uid) { const l = await c.j("GET", "/api/people"); uid = l.d.people.find(p => p.username === "j3r3-tmp").id; r = await c.j("PATCH", "/api/people/" + uid, { password: tpw, is_active: true, current_password: pw() }); show("reset tmp", r); }
const u = new Client(); show("tmp login", await u.login("j3r3-tmp", tpw));
show("tmp session", await u.j("GET", "/api/session"));
const D = o.dLetter;
const cp = await c.j("GET", `/api/documents/${D}`); const ver = await c.j("GET", `/api/documents/${D}/versions`); const vid = ver.d.versions?.[0]?.id;
const paths = [["GET", "/api/documents/" + D], ["PATCH", "/api/documents/" + D, { title: "pwned" }], ["GET", `/api/documents/${D}/original`], ["GET", `/api/documents/${D}/archive`], ["GET", `/api/documents/${D}/pages/1.png`], ["GET", `/api/documents/${D}/pages`], ["GET", `/api/documents/${D}/versions`], ["GET", `/api/documents/${D}/versions/${vid}/download`], ["GET", `/api/documents/${D}/notes`], ["POST", `/api/documents/${D}/notes`, { body: "x" }], ["GET", `/api/documents/${D}/history`], ["GET", `/api/documents/${D}/similar`], ["GET", `/api/documents/${D}/filing-suggestions`], ["GET", `/api/documents/${D}/export`], ["GET", `/api/documents/${D}/copies`], ["POST", `/api/documents/${D}/copies`, {}], ["GET", `/api/documents/${D}/links`], ["GET", `/api/documents/${D}/custom-fields`], ["GET", `/api/documents/${D}/access`], ["POST", `/api/documents/${D}/access`, { user_id: uid, level: "edit" }], ["GET", `/api/documents/${D}/shares`], ["POST", `/api/documents/${D}/shares`, {}], ["POST", `/api/documents/${D}/trash`], ["POST", `/api/documents/${D}/retry`], ["POST", `/api/documents/${D}/reprocess`], ["POST", `/api/documents/${D}/purge`, {}], ["POST", `/api/documents/${D}/split`, {}], ["POST", "/api/documents/bulk-tags", { document_ids: [D], tag_id: o.TA, action: "add" }], ["POST", "/api/documents/bulk-trash", { document_ids: [D] }], ["POST", "/api/documents/export", { document_ids: [D] }], ["POST", "/api/documents/merge", { document_ids: [D, o.dPdf] }], ["DELETE", "/api/tags/" + o.TP], ["PATCH", "/api/tags/" + o.TP, { name: "pwn" }], ["GET", "/api/tags/" + o.TP + "/label"], ["DELETE", "/api/agents/" + o.gB.id], ["GET", "/api/people"], ["POST", "/api/people", { username: "j3r3-x", password: tpw, current_password: tpw }], ["PATCH", "/api/people/" + uid, { is_admin: true, current_password: tpw }], ["GET", "/api/backups"], ["POST", "/api/backups", {}], ["GET", "/api/browse-exports"], ["GET", "/api/jobs"], ["GET", "/api/semantic-settings"], ["POST", "/api/semantic-settings", { mode: "nas" }], ["GET", "/admin/"], ["GET", "/api/overview"], ["GET", "/api/object-access/tag/" + o.TP], ["POST", "/api/object-access/tag/" + o.TP, { user_id: uid, level: "edit" }], ["GET", "/api/sources"], ["GET", "/api/source-apps"], ["GET", "/api/trash-retention"], ["GET", "/api/purge-jobs"]];
for (const [m, p, b] of paths) { const x = await u.j(m, p, b); console.log(("tmp " + m + " " + p.replace(/[0-9a-f-]{36}/g, ":id")).padEnd(52), x.s, S(x.d).slice(0, 110)); }
r = await u.j("GET", "/api/documents"); console.log("tmp docs", r.d.documents.length, "tags", (await u.j("GET", "/api/tags")).d.tags?.length, "agents", (await u.j("GET", "/api/agents")).d.grants?.length, "events", (await u.j("GET", "/api/agents/events")).d.events?.length);
r = await u.j("GET", "/api/documents?q=conversion"); console.log("tmp search", r.d.documents.length);
r = await u.j("GET", "/api/documents?tag_id=" + o.TA); console.log("tmp filter by my tag", r.s, S(r.d).slice(0, 100));
// tmp's agent cannot see my docs
r = await u.j("POST", "/api/agents", { name: "j3r3-tmp-agent", scopes: ["documents:search", "documents:text", "documents:tag"], expires_in_days: 1 }); const ut = r.d.token; console.log("tmp agent", r.s);
r = await u.j("POST", "/api/agents", { name: "j3r3-tmp-agent2", scopes: ["documents:search"], filter_tag_id: o.TA }); show("tmp agent w/ my tag filter", r);
r = await tool(ut, "search_documents", {}); console.log("tmp agent search", r.r.documents?.length);
r = await tool(ut, "get_document_text", { document_id: D }); console.log("tmp agent text of my doc", r.err, S(r.r));
r = await tool(ut, "change_document_tags", { document_id: D, add: [o.TP] }); console.log("tmp agent tag my doc", r.err, S(r.r));
// share view
r = await c.j("POST", `/api/documents/${D}/access`, { user_id: uid, level: "view" }); show("share view", r); const gid = r.d.id ?? r.d.grant?.id;
for (const [m, p, b] of [["GET", "/api/documents/" + D], ["GET", `/api/documents/${D}/original`], ["PATCH", "/api/documents/" + D, { title: "pwned" }], ["POST", `/api/documents/${D}/trash`], ["POST", `/api/documents/${D}/notes`, { body: "x" }], ["POST", `/api/documents/${D}/access`, { user_id: uid, level: "edit" }], ["POST", `/api/documents/${D}/shares`, {}], ["GET", `/api/documents/${D}/history`], ["GET", `/api/documents/${D}/notes`], ["GET", `/api/documents/${D}/copies`], ["POST", `/api/documents/${D}/reprocess`], ["GET", `/api/documents/${D}/export`], ["POST", "/api/documents/bulk-tags", { document_ids: [D], tag_id: o.TA, action: "remove" }]]) { const x = await u.j(m, p, b); console.log(("view-shared " + m + " " + p.replace(/[0-9a-f-]{36}/g, ":id")).padEnd(52), x.s, S(x.d).slice(0, 110)); }
r = await u.j("GET", "/api/documents?view=shared"); console.log("shared list", r.d.documents.map(d => [d.title, d.access, d.shared_by]));
r = await tool(ut, "get_document_text", { document_id: D }); console.log("tmp agent text of shared doc", r.err, S(r.r));
r = await c.j("DELETE", `/api/documents/${D}/access/${gid}`); show("unshare", r);
show("after unshare", await u.j("GET", "/api/documents/" + D));
// public share link
r = await c.j("POST", `/api/documents/${D}/shares`, { expires_in_days: 1 }); console.log("share link", r.s, Object.keys(r.d)); const st = r.d.token || r.d.url?.split("/").pop(); const sid = r.d.id;
let x = await fetch(BASE + "/api/share-links/" + st); console.log("anon share GET", x.status, x.headers.get("content-type"), x.headers.get("cache-control"), x.headers.get("content-disposition"));
x = await fetch(BASE + "/api/share-links/" + st.slice(0, -2) + "zz"); console.log("anon bad token", x.status);
show("revoke link", await c.j("DELETE", `/api/documents/${D}/shares/${sid}`));
x = await fetch(BASE + "/api/share-links/" + st); console.log("anon after revoke", x.status);
// deactivate tmp: sessions, agent token
u.cookiesBefore = { ...u.cookies };
show("deactivate tmp", await c.j("PATCH", "/api/people/" + uid, { is_active: false, current_password: pw() }));
show("tmp session after deactivate", await u.j("GET", "/api/documents"));
console.log("tmp agent after deactivate", (await mcp(ut, "tools/list")).s);
show("tmp login after deactivate", await new Client().login("j3r3-tmp", tpw));
fs.writeFileSync("s3-out.json", JSON.stringify({ uid }));

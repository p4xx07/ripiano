import { launch, login, MOBILE, ART } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext({ ...MOBILE, viewport: { width: 320, height: 640 } })).newPage();
await login(p, "it");
for (const v of ["Tutti i documenti", "Agenti", "Sorgenti"]) {
  const m = p.getByRole("button", { name: "Apri o chiudi il menu" }); await m.click(); await p.waitForTimeout(300);
  await p.getByRole("button", { name: v, exact: true }).click(); await p.waitForTimeout(1500);
  console.log(v, await p.evaluate(() => { const W = window.innerWidth; const out = []; for (const e of document.querySelectorAll("main *")) { const r = e.getBoundingClientRect(); if (r.right > W + 1 && r.width > 0) out.push(e.tagName + "." + e.className + " " + Math.round(r.right)); } return [document.documentElement.scrollWidth, out.slice(0, 4)]; }));
}
await p.screenshot({ path: ART + "/mobile320-sources.png" });
await b.close();

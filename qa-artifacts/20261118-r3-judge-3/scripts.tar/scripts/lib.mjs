import fs from "node:fs";
export const BASE = "http://localhost:18080";
export const FIX = "/Users/debotta/dbrepos/ripiano/apps/web/e2e/fixtures/";
export function pw() {
  const env = fs.readFileSync("/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judges.env", "utf8");
  return env.match(/^JUDGE3_PASSWORD=(.*)$/m)[1].trim().replace(/^["']|["']$/g, "");
}
export class Client {
  constructor() { this.cookies = {}; this.bearer = null; }
  hdr(extra = {}) {
    const h = { ...extra };
    const c = Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join("; ");
    if (c) h.Cookie = c;
    if (this.cookies.csrftoken) h["X-CSRFToken"] = this.cookies.csrftoken;
    if (this.bearer) h.Authorization = "Bearer " + this.bearer;
    if (!h.Origin) h.Origin = BASE;
    return h;
  }
  async raw(method, path, body, extra = {}) {
    const opts = { method, headers: this.hdr(extra), redirect: "manual" };
    if (body !== undefined) {
      if (body instanceof FormData || typeof body === "string" || body instanceof Uint8Array) opts.body = body;
      else { opts.body = JSON.stringify(body); opts.headers["Content-Type"] = "application/json"; }
    }
    const r = await fetch(BASE + path, opts);
    for (const sc of r.headers.getSetCookie?.() || []) {
      const [kv] = sc.split(";"); const i = kv.indexOf("=");
      this.cookies[kv.slice(0, i)] = kv.slice(i + 1);
    }
    return r;
  }
  async j(method, path, body, extra) {
    const r = await this.raw(method, path, body, extra);
    const t = await r.text(); let d; try { d = JSON.parse(t); } catch { d = t.slice(0, 500); }
    return { s: r.status, d, h: r.headers };
  }
  async login(username, password) {
    await this.raw("GET", "/api/session");
    return this.j("POST", "/api/session", { username, password });
  }
}
export async function judge() { const c = new Client(); const r = await c.login("judge3", pw()); if (r.s !== 200) throw new Error("login " + r.s + JSON.stringify(r.d)); return c; }
export const sleep = (ms) => new Promise(r => setTimeout(r, ms));
export async function upload(c, bytes, name, type = "application/octet-stream", headers = {}) {
  const fd = new FormData(); fd.append("document", new Blob([bytes], { type }), name);
  return c.j("POST", "/api/documents", fd, headers);
}
export async function waitDoc(c, id, ms = 90000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const r = await c.j("GET", "/api/documents/" + id); if (r.d.status === "ready" || r.d.status === "failed") return r.d; await sleep(1500); }
  return (await c.j("GET", "/api/documents/" + id)).d;
}
export async function mcp(token, method, params = {}, extra = {}) {
  const r = await fetch(BASE + "/mcp", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json, text/event-stream", ...(token ? { Authorization: "Bearer " + token } : {}), ...extra }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
  const t = await r.text(); let d; try { d = JSON.parse(t); } catch { d = t.slice(0, 300); }
  return { s: r.status, d, h: r.headers };
}
export const tool = async (token, name, args = {}) => { const r = await mcp(token, "tools/call", { name, arguments: args }); return { s: r.s, r: r.d?.result?.structuredContent ?? r.d, err: r.d?.result?.isError }; };

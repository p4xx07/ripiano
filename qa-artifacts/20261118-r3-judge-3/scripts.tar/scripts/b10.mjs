import { open, shot } from "./blib.mjs";
import { pw, BASE } from "./lib.mjs";
const { browser, page, errors } = await open(false);
const act = () => page.evaluate(() => { const e = document.activeElement; if (!e) return "none"; const s = getComputedStyle(e); return `${e.tagName.toLowerCase()}${e.id ? "#" + e.id : ""}[${(e.getAttribute("aria-label") || e.labels?.[0]?.textContent || e.textContent || e.placeholder || "").trim().slice(0, 40)}] outline=${s.outlineStyle}/${s.outlineWidth} shadow=${s.boxShadow !== "none"}`; });
await page.goto(BASE + "/");
await page.waitForTimeout(800);
await page.keyboard.press("Tab"); console.log("signin tab1:", await act());
await page.getByLabel("Username").focus(); await page.keyboard.type("judge3"); await page.keyboard.press("Tab"); console.log("tab->", await act()); await page.keyboard.type(pw()); await page.keyboard.press("Enter");
await page.getByRole("heading", { level: 1 }).waitFor(); await page.waitForTimeout(1200);
console.log("after sign-in focus:", await act());
await page.keyboard.press("Tab"); console.log("tab1 (skip link?):", await act()); await shot(page, "d-40-skip-link");
await page.keyboard.press("Enter"); await page.waitForTimeout(300); console.log("after skip:", await act());
await page.keyboard.press("/"); console.log("/ ->", await act());
await page.keyboard.type("otter"); await page.waitForTimeout(1000); await page.keyboard.press("Escape"); console.log("esc in search ->", await act(), "| value:", await page.getByPlaceholder(/Search text/).inputValue());
await page.keyboard.press("Tab"); await page.keyboard.press("Tab"); console.log("tab tab:", await act());
await page.locator("body").click({ position: { x: 700, y: 20 } });
await page.keyboard.press("j"); console.log("j ->", await act()); await page.keyboard.press("j"); console.log("j ->", await act()); await page.keyboard.press("k"); console.log("k ->", await act()); await shot(page, "d-41-jk-focus");
await page.keyboard.press("Enter"); await page.waitForTimeout(900); console.log("enter -> dialog:", await page.getByRole("dialog").count(), "focus:", await act());
// focus trap
let seen = new Set(); let outside = 0; for (let i = 0; i < 90; i++) { await page.keyboard.press("Tab"); const inDlg = await page.evaluate(() => !!document.activeElement.closest('[role=dialog]')); if (!inDlg) outside++; seen.add(await act()); } console.log("dialog tab stops:", seen.size, "outside dialog:", outside);
await page.keyboard.press("Shift+Tab"); console.log("shift-tab:", await act());
await page.keyboard.press("Escape"); await page.waitForTimeout(400); console.log("esc -> dialog:", await page.getByRole("dialog").count(), "focus returned to:", await act());
await page.keyboard.press("n"); await page.waitForTimeout(500); console.log("n -> dialog:", await page.getByRole("dialog").count(), "focus:", await act()); await page.keyboard.press("Escape"); await page.waitForTimeout(300); console.log("esc ->", await page.getByRole("dialog").count(), await act());
await page.keyboard.press("?"); await page.waitForTimeout(500); console.log("? ->", (await page.getByRole("dialog").innerText().catch(() => "none")).replace(/\n+/g, " | ").slice(0, 700)); await shot(page, "d-42-shortcuts"); await page.keyboard.press("Escape");
for (const k of ["i", "t", "p", "o", "a", "s", "l"]) { await page.keyboard.press("g"); await page.keyboard.press(k); await page.waitForTimeout(600); console.log(`g ${k} ->`, await page.locator("h1").innerText(), "| focus:", await act()); }
// keyboard-only agent create + revoke
await page.keyboard.press("g"); await page.keyboard.press("a"); await page.waitForTimeout(600);
const name = "j3kbd-" + Date.now() % 100000;
await page.getByPlaceholder("e.g. Local Mac classifier").focus(); await page.keyboard.type(name); await page.keyboard.press("Enter"); await page.waitForTimeout(900);
console.log("agent created by Enter:", await page.getByText("Copy this token now").count(), "focus:", await act());
const rv = page.getByRole("button", { name: `Revoke ${name}` }); await rv.focus(); await page.keyboard.press("Enter"); await page.waitForTimeout(300); console.log("revoke confirm focus:", await act()); await page.keyboard.press("Tab"); console.log("  tab:", await act());
await page.getByRole("button", { name: "Yes, revoke" }).focus(); await page.keyboard.press("Enter"); await page.waitForTimeout(600); console.log("after revoke focus:", await act(), "| status:", (await page.locator(".agent-card").filter({ hasText: name }).innerText()).replace(/\n+/g, " | ").slice(0, 80));
// generic a11y audit across current page
console.log("errors", errors);
await browser.close();

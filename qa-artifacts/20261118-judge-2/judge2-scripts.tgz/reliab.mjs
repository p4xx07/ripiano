import { launch, login, MOBILE, ART, FIX, save, ORIGIN, audit } from "./common.mjs";
import { readFileSync } from "node:fs";
const b = await launch(); const ctx = await b.newContext(MOBILE); const p = await ctx.newPage();
const { stamp } = JSON.parse(readFileSync("ids2.json", "utf8"));
await login(p, "it");
const msgs = async () => (await p.locator("[role=status],[role=alert]").allInnerTexts()).filter(Boolean).map(s => s.replace(/\s+/g, " "));
async function upload(btn, file) {
  await p.getByRole("button", { name: "Aggiungi", exact: true }).click();
  const ch = p.waitForEvent("filechooser");
  await p.getByRole("dialog").getByRole("button", { name: new RegExp("^" + btn) }).click();
  await (await ch).setFiles(file);
  await p.waitForTimeout(2500);
  const r = await msgs();
  if (await p.getByRole("dialog").isVisible().catch(() => false)) await p.getByRole("dialog").getByRole("button", { name: "Chiudi", exact: true }).click();
  return r;
}
// 1. offline upload
await ctx.setOffline(true);
console.log("offline upload:", await upload("Scegli dalle foto", { name: `j2off-${stamp}.png`, mimeType: "image/png", buffer: readFileSync(`${FIX}/judge.png`) }));
await p.screenshot({ path: ART + "/mobile-offline-upload.png" });
await ctx.setOffline(false);
// 2. aborted upload
await p.route("**/api/documents", (route) => route.request().method() === "POST" ? route.abort("connectionreset") : route.continue());
console.log("aborted upload:", await upload("Sfoglia i file", { name: `j2abort-${stamp}.pdf`, mimeType: "application/pdf", buffer: readFileSync(`${FIX}/three-pages.pdf`) }));
await p.unroute("**/api/documents");
// 3. corrupt "pdf" (legacy doc bytes under a pdf name) + wrong type
console.log("fake pdf:", await upload("Sfoglia i file", { name: `j2bad-${stamp}.pdf`, mimeType: "application/pdf", buffer: readFileSync(`${FIX}/office-legacy.doc`) }));
console.log("unsupported zip:", await upload("Sfoglia i file", { name: `j2bad-${stamp}.zip`, mimeType: "application/zip", buffer: readFileSync(`${FIX}/office-slides.pptx`) }));
console.log("mixed batch:", await upload("Sfoglia i file", [
  { name: `j2mix-${stamp}.odt`, mimeType: "application/vnd.oasis.opendocument.text", buffer: readFileSync(`${FIX}/office-open.odt`) },
  { name: `j2mix-${stamp}.exe`, mimeType: "application/octet-stream", buffer: readFileSync(`${FIX}/office-legacy.doc`) }]));
await p.screenshot({ path: ART + "/mobile-upload-errors.png" });
await p.waitForTimeout(25000);
// inbox
const menu = p.getByRole("button", { name: "Apri o chiudi il menu" });
await menu.click(); await p.getByRole("button", { name: "In arrivo", exact: true }).click(); await p.waitForTimeout(2000);
save("inbox.yml", await p.locator("main").ariaSnapshot());
await p.screenshot({ path: ART + "/mobile-inbox.png", fullPage: true });
console.log("inbox focus:", await p.evaluate(() => document.activeElement?.outerHTML.slice(0, 100)));
const retry = p.getByRole("button", { name: /Riprova/ }).first();
if (await retry.isVisible().catch(() => false)) { await retry.click(); await p.waitForTimeout(3000); console.log("after retry:", await msgs()); }
await b.close();

import { chromium } from "@playwright/test";
import { readFileSync, writeFileSync } from "node:fs";

export const ORIGIN = "http://localhost:18080";
export const ART = "/Users/debotta/dbrepos/ripiano/qa-artifacts/20261118-judge-2";
export const SCR = "/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/j2";
export const FIX = "/Users/debotta/dbrepos/ripiano/apps/web/e2e/fixtures";
const env = readFileSync("/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judges.env", "utf8");
export const USER = "judge2";
export const PASS = env.match(/^JUDGE2_PASSWORD=(.*)$/m)[1].trim();

export async function launch() {
  return chromium.launch({ channel: "chrome", headless: true });
}
export const MOBILE = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3, locale: "it-IT", timezoneId: "Europe/Rome",
  userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1" };
export const DESKTOP = { viewport: { width: 1440, height: 900 }, locale: "it-IT", timezoneId: "Europe/Rome" };

export async function login(page, lang = "it") {
  await page.goto(ORIGIN + "/");
  await page.locator("select").first().waitFor();
  const langSel = page.getByRole("combobox", { name: /^(Language|Lingua)$/ });
  await langSel.selectOption(lang);
  await page.getByRole("textbox", { name: /^(Username|Nome utente)$/ }).fill(USER);
  await page.getByLabel("Password").fill(PASS);
  await page.getByRole("button", { name: /^(Sign in|Accedi)$/ }).click();
  await page.getByRole("heading", { level: 1 }).first().waitFor();
  await page.waitForTimeout(800);
}

export async function audit(page) {
  return page.evaluate(() => {
    const problems = [];
    const visible = (el) => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
    const short = (el) => el.outerHTML.slice(0, 110);
    for (const el of document.querySelectorAll("button, a[href], [role=button], input:not([type=hidden]), select, textarea, summary")) {
      if (!visible(el)) continue;
      const r = el.getBoundingClientRect();
      if ((r.width < 24 || r.height < 24) && el.type !== "checkbox" && el.type !== "radio") problems.push(`small target ${Math.round(r.width)}x${Math.round(r.height)}: ${short(el)}`);
      if (["BUTTON","A","SUMMARY"].includes(el.tagName) || el.getAttribute("role")==="button") {
        const name = (el.getAttribute("aria-label") || el.textContent || el.getAttribute("title") || "").trim();
        if (!name) problems.push(`no accessible name: ${short(el)}`);
      } else {
        const labelledBy = (el.getAttribute("aria-labelledby") || "").split(" ").map((id) => document.getElementById(id)?.textContent ?? "").join("");
        const forLabel = el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent ?? "" : "";
        const label = el.getAttribute("aria-label") || labelledBy || forLabel || el.closest("label")?.textContent || el.getAttribute("title");
        if (!label?.trim()) problems.push(`field labelled only by placeholder/none: ${short(el)}`);
      }
    }
    const ids = new Map();
    for (const el of document.querySelectorAll("[id]")) ids.set(el.id, (ids.get(el.id) ?? 0) + 1);
    for (const [id, c] of ids) if (c > 1) problems.push(`duplicate id ${id} x${c}`);
    for (const img of document.querySelectorAll("img")) if (visible(img) && !img.hasAttribute("alt")) problems.push(`img no alt: ${short(img)}`);
    if (document.documentElement.scrollWidth > window.innerWidth + 1) problems.push(`horizontal overflow ${document.documentElement.scrollWidth}>${window.innerWidth}`);
    return problems;
  });
}

const EN = /\b(the|your|and|with|this|that|from|document|documents|files?|search|save|delete|cancel|close|add|upload|tags?|settings|loading|error|failed|none|yes|no|select|choose|new|edit|show|hide|more|less|done|next|back|sign|account|password|paper|copy|shelf|filters?|sort|title|sender|type|date|created|updated|owner|share|people|agent|grant|scope|token|retry|waiting|processing|queued|ready|unknown|minutes?|hours?|days?|ago)\b/i;
export async function englishLeaks(page) {
  return page.evaluate((src) => {
    const re = new RegExp(src, "i");
    const out = new Set();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      const t = n.textContent.trim();
      const el = n.parentElement;
      if (!t || !el || el.closest("script,style,.document-snippet")) continue;
      if (el.getClientRects().length === 0) continue;
      if (re.test(t)) out.add(t.slice(0, 120));
    }
    for (const el of document.querySelectorAll("[aria-label],[title],[placeholder]")) {
      for (const a of ["aria-label", "title", "placeholder"]) { const v = el.getAttribute(a); if (v && re.test(v)) out.add(`@${a}: ${v.slice(0,100)}`); }
    }
    return [...out];
  }, EN.source);
}

export function save(name, data) { writeFileSync(`${SCR}/${name}`, typeof data === "string" ? data : JSON.stringify(data, null, 2)); }

import { open, signIn, nav, shot } from "./blib.mjs";
import { judge, BASE } from "./lib.mjs";
import fs from "node:fs";
const stamp = fs.readFileSync("/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judge3/b2-stamp.txt", "utf8");
const { browser, page, errors, context } = await open(false);
const step = async (name, fn) => { try { await fn(); console.log("OK  ", name); } catch (e) { console.log("FAIL", name, String(e).split("\n")[0].slice(0, 200)); await shot(page, "fail-" + name.replace(/\W+/g, "-")).catch(() => {}); } };
await signIn(page);
const title = `j3b-${stamp}-three-pages`;
const c = await judge();
const doc = (await c.j("GET", "/api/documents?q=" + title)).d.documents[0]; const sticker = doc.physical_copies[0].sticker_code; console.log("sticker", sticker, JSON.stringify(doc.physical_copies[0]).slice(0, 300));
const search = page.getByPlaceholder(/Search text/);
const results = async () => (await page.locator("main").innerText()).split("Select documents")[1]?.replace(/\n+/g, " | ").slice(0, 420);
for (const q of [sticker, `J3B Sender ${stamp}`, `sender:"J3B Sender ${stamp}"`, `tag:j3b-tag-${stamp}`, "date:2026-03", "date:2026-03-14", "first otter", "otter date:2026-03 tag:j3b-tag-" + stamp, "lampone", "condominio", "avviso tari", "date:14/03/2026", "sender:", "tag:nonexistent-zzz", "zzzqqqnomatch"]) {
  await search.fill(q); await page.waitForTimeout(900); console.log(`Q[${q}] ->`, await results());
}
await search.fill("zzzqqqnomatch"); await page.waitForTimeout(700); await shot(page, "d-10-no-results");
await search.fill("date:14/03/2026"); await page.waitForTimeout(700); await shot(page, "d-10b-bad-date");
await search.fill(sticker); await page.waitForTimeout(900); await shot(page, "d-11-search-sticker");
// Filters panel
await search.fill(""); await page.getByRole("button", { name: "Filters" }).click(); await page.waitForTimeout(500); await shot(page, "d-12-filters");
console.log("FILTERS:", (await page.locator("main").innerText()).split("Filters")[1]?.replace(/\n+/g, " | ").slice(0, 500));
// Paper archive
await nav(page, "Paper archive"); await page.waitForTimeout(800); await shot(page, "d-13-paper-archive", { fullPage: true });
console.log("PAPER ARCHIVE:", (await page.locator("main").innerText()).replace(/\n+/g, " | ").slice(0, 1500));
const ctl = await page.locator("main").locator("button:visible, select:visible, a:visible, input:visible").evaluateAll(els => els.map(e => `${e.tagName.toLowerCase()}[${e.getAttribute("aria-label") || e.textContent.trim().slice(0, 40) || e.placeholder}]`)); console.log("   controls:", ctl.slice(0, 40).join(" "));
// label
const lab = await c.raw("GET", `/api/copies/${doc.physical_copies[0].id}/label`); console.log("label", lab.status, lab.headers.get("content-type"), lab.headers.get("content-security-policy")); const lt = await lab.text(); fs.writeFileSync("/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judge3/label.html", lt); console.log("  label len", lt.length, lt.slice(0, 300).replace(/\n/g, " "));
console.log(errors);
await browser.close();

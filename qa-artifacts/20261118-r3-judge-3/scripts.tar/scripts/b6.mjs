import { open, signIn, nav, shot } from "./blib.mjs";
import { judge, BASE, mcp } from "./lib.mjs";
import fs from "node:fs";
const stamp = fs.readFileSync("/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judge3/b2-stamp.txt", "utf8");
const { browser, page, errors, context } = await open(false);
const step = async (name, fn) => { try { await fn(); console.log("OK  ", name); } catch (e) { console.log("FAIL", name, String(e).split("\n")[0].slice(0, 200)); await shot(page, "fail-" + name.replace(/\W+/g, "-")).catch(() => {}); } };
const main = async (n = 1200) => (await page.locator("main").innerText()).replace(/\n+/g, " | ").slice(0, n);
await signIn(page);
const c = await judge();
const doc = (await c.j("GET", `/api/documents?q=j3b-${stamp}-three-pages`)).d.documents[0]; const sticker = doc.physical_copies[0].sticker_code;
await nav(page, "Paper archive");
await step("find sticker", async () => { await page.getByLabel("Sticker code").fill(sticker.toLowerCase()); await page.getByRole("button", { name: "Find" }).click(); await page.waitForTimeout(900); console.log("  ", (await main(700)).split("Find |")[1]?.slice(0, 400)); await shot(page, "d-14-sticker-found"); });
await step("find bogus sticker", async () => { await page.getByLabel("Sticker code").fill("R-ZZZZZZZZ"); await page.getByRole("button", { name: "Find" }).click(); await page.waitForTimeout(900); console.log("  ", (await main(700)).split("Find |")[1]?.slice(0, 200)); });
await step("view contents", async () => { await page.getByRole("button", { name: "View contents" }).first().click(); await page.waitForTimeout(900); console.log("  ", (await main(1500)).slice(300, 1100)); await shot(page, "d-15-location-contents"); });
// move via document dialog
await nav(page, "All documents");
await page.getByRole("button", { name: `j3b-${stamp}-three-pages`, exact: true }).first().click();
const dlg = page.getByRole("dialog");
await step("move copy", async () => { await dlg.getByLabel(`New location for paper copy ${sticker}`).selectOption({ label: "J3 Shelf A" }); await dlg.getByRole("button", { name: "Move", exact: true }).click(); await page.waitForTimeout(900); await dlg.getByRole("button", { name: "History" }).click(); await page.waitForTimeout(700); const t = await dlg.innerText(); const i = t.indexOf("Paper copies"); console.log("  ", t.slice(i, i + 500).replace(/\n+/g, " | ")); await shot(page, "d-16-copy-moved-history"); });
await step("mark missing", async () => { await dlg.getByRole("button", { name: "Mark missing" }).click(); await page.waitForTimeout(900); const t = await dlg.innerText(); const i = t.indexOf("Paper copies"); console.log("  ", t.slice(i, i + 300).replace(/\n+/g, " | ")); await dlg.getByRole("button", { name: /found/i }).first().click(); await page.waitForTimeout(600); });
await step("print sticker link", async () => { const [p2] = await Promise.all([context.waitForEvent("page"), dlg.getByRole("link", { name: "Print sticker" }).click()]); await p2.waitForLoadState(); await p2.screenshot({ path: "/Users/debotta/dbrepos/ripiano/qa-artifacts/20261118-r3-judge-3/d-17-sticker-label.png" }); console.log("   label text:", (await p2.locator("body").innerText()).replace(/\n+/g, " | ")); await p2.close(); });
await page.keyboard.press("Escape"); await page.waitForTimeout(300); console.log("dialog closed by Esc:", (await dlg.count()) === 0);
// Agents
await nav(page, "Agents"); await page.waitForTimeout(600); await shot(page, "d-18-agents", { fullPage: true }); console.log("AGENTS:", await main(1800));
await step("create agent UI", async () => { await page.getByPlaceholder("e.g. Local Mac classifier").fill("j3b-ui-agent-" + stamp); await page.getByLabel("Read OCR text").check(); const ctl = await page.locator("main form").first().locator("input:visible, select:visible, button:visible").evaluateAll(els => els.map(e => `${e.tagName.toLowerCase()}[${e.getAttribute("aria-label") || e.labels?.[0]?.textContent?.trim().slice(0, 40) || e.textContent.trim().slice(0, 40)}]`)); console.log("   form:", ctl.join(" ")); await page.getByRole("button", { name: "Create agent token" }).click(); await page.waitForTimeout(800); const tokenBox = page.getByLabel("New agent token"); const tok = await tokenBox.inputValue(); console.log("   token shown prefix:", tok.slice(0, 4), "len", tok.length, "type attr:", await tokenBox.getAttribute("type")); await shot(page, "d-19-agent-created", { mask: [tokenBox] }); console.log("   new-token area:", (await main(3000)).match(/Copy this token now.{0,400}/)?.[0]); const tl = await mcp(tok, "tools/list"); console.log("   tools:", tl.d.result.tools.map(t => t.name)); await page.reload(); await nav(page, "Agents"); console.log("   token still shown after reload:", await page.getByLabel("New agent token").count()); const card = page.locator(".agent-card").filter({ hasText: "j3b-ui-agent-" + stamp }); await card.getByRole("button", { name: /Revoke/ }).click(); await card.getByRole("button", { name: "Yes, revoke" }).click(); await page.waitForTimeout(600); console.log("   card:", (await card.innerText()).replace(/\n+/g, " | ")); console.log("   mcp after UI revoke:", (await mcp(tok, "tools/list")).s); });
await shot(page, "d-20-agents-activity", { fullPage: true });
console.log(errors);
await browser.close();

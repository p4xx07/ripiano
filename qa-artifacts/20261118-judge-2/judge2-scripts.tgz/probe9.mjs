import { launch, login, DESKTOP, MOBILE, ART } from "./common.mjs";
for (const [nm, cfg] of [["desktop", DESKTOP], ["desktop768", { ...DESKTOP, viewport: { width: 1280, height: 720 } }]]) {
const b = await launch(); const p = await (await b.newContext(cfg)).newPage();
await login(p, "it");
await p.mouse.move(100, 400); await p.mouse.wheel(0, 3000); await p.waitForTimeout(500);
const r = await p.evaluate(() => [...document.querySelectorAll(".sidebar select, .sidebar button")].slice(-4).map(b2 => { const r = b2.getBoundingClientRect(); const e = document.elementFromPoint(r.left + 5, r.top + r.height / 2); return (b2.getAttribute("aria-label") || b2.textContent.trim()).slice(0, 20) + ":" + Math.round(r.top) + (e && (e === b2 || b2.contains(e)) ? " ok" : " UNREACHABLE"); }));
console.log(nm, r, await p.evaluate(() => [document.querySelector(".sidebar").scrollHeight, innerHeight]));
const acct = p.locator(".sidebar button").last(); console.log("account button text:", await acct.innerText());
if (nm === "desktop768") await p.screenshot({ path: ART + "/desktop1280x720-sidebar.png" });
await b.close();
}

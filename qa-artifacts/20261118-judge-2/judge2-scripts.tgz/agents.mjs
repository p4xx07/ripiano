import { launch, login, DESKTOP, ART, save, ORIGIN } from "./common.mjs";
import { readFileSync } from "node:fs";
const b = await launch(); const ctx = await b.newContext(DESKTOP); const p = await ctx.newPage();
const { stamp } = JSON.parse(readFileSync("ids2.json", "utf8"));
const { tag } = JSON.parse(readFileSync("ids.json", "utf8"));
await login(p, "it");
await p.getByRole("button", { name: "Agenti", exact: true }).click(); await p.waitForTimeout(1500);
async function create(name, text, onlyTag) {
  await p.getByRole("textbox", { name: "Nome" }).fill(name);
  const t = p.getByRole("checkbox", { name: "Leggere il testo OCR" });
  if (text) await t.check(); else await t.uncheck();
  if (onlyTag) await p.getByRole("combobox", { name: "Accesso ai documenti" }).selectOption({ label: `Solo documenti “${onlyTag}”` });
  else await p.getByRole("combobox", { name: "Accesso ai documenti" }).selectOption({ index: 0 });
  await p.getByRole("button", { name: "Crea token dell'agente" }).click(); await p.waitForTimeout(1500);
  const tok = await p.getByRole("textbox", { name: /token/i }).first().inputValue().catch(async () => (await p.locator("code").allInnerTexts()).find(x => x.length > 30));
  const mcp = (await p.locator("main").innerText()).match(/URL MCP:\s*(\S+)/)?.[1];
  return { tok, mcp };
}
const A = await create(`J2 cloud ${stamp}`, false, null);
const B = await create(`J2 locale ${stamp}`, true, tag);
console.log("mcp url:", A.mcp, "tokens len:", A.tok?.length, B.tok?.length);
await p.evaluate(() => { for (const e of document.querySelectorAll("input, code")) if ((e.value || e.textContent || "").length > 30) { if (e.value) e.value = "••••MASKED••••"; else e.textContent = "••••MASKED••••"; } });
await p.screenshot({ path: ART + "/desktop-agents-created.png", fullPage: true });
const url = A.mcp?.startsWith("http") ? A.mcp : ORIGIN + "/mcp";
let sid = {};
async function rpc(tok, method, params, id = 1) {
  const r = await p.request.post(url, { headers: { Authorization: `Bearer ${tok}`, "Content-Type": "application/json", Accept: "application/json, text/event-stream", ...(sid[tok] ? { "mcp-session-id": sid[tok] } : {}) }, data: { jsonrpc: "2.0", id, method, params } });
  const h = r.headers()["mcp-session-id"]; if (h) sid[tok] = h;
  const body = await r.text();
  const m = body.match(/data: (.*)/); let j = null; try { j = JSON.parse(m ? m[1] : body); } catch {}
  return { status: r.status(), j, raw: body.slice(0, 300) };
}
async function init(tok) {
  const r = await rpc(tok, "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "judge", version: "1" } });
  await p.request.post(url, { headers: { Authorization: `Bearer ${tok}`, "Content-Type": "application/json", Accept: "application/json, text/event-stream", ...(sid[tok] ? { "mcp-session-id": sid[tok] } : {}) }, data: { jsonrpc: "2.0", method: "notifications/initialized" } });
  return r.status;
}
const out = {};
for (const [k, X] of [["A", A], ["B", B]]) {
  out[k] = { init: await init(X.tok) };
  const tl = await rpc(X.tok, "tools/list", {}, 2);
  out[k].tools = tl.j?.result?.tools?.map(t => t.name) ?? tl.raw;
  for (const q of ["lampone", "9473", "j2cam"]) {
    const r = await rpc(X.tok, "tools/call", { name: "search_documents", arguments: { query: q } }, 3);
    out[k]["search_" + q] = JSON.stringify(r.j?.result ?? r.j?.error ?? r.raw).slice(0, 400);
  }
  const r = await rpc(X.tok, "tools/call", { name: "get_document_text", arguments: { document_id: "0f780222-0b5d-4baa-b690-d41e70bbafc8" } }, 4);
  out[k].text_cam = JSON.stringify(r.j?.result ?? r.j?.error ?? r.raw).slice(0, 300);
  const r2 = await rpc(X.tok, "tools/call", { name: "get_document_text", arguments: { document_id: "8f53c1e3-95b8-4795-b11a-0630d35cf63e" } }, 5);
  out[k].text_msg_unfiltered = JSON.stringify(r2.j?.result ?? r2.j?.error ?? r2.raw).slice(0, 300);
}
// revoke A
await p.reload(); await p.waitForTimeout(1500);
await p.getByRole("button", { name: "Agenti", exact: true }).click().catch(() => {}); await p.waitForTimeout(1200);
const cardA = p.locator("li, article, .agent-card").filter({ hasText: `J2 cloud ${stamp}` }).last();
await cardA.getByRole("button", { name: "Revoca" }).click(); await p.waitForTimeout(800);
const confirm = p.getByRole("button", { name: /Revoca/ }).filter({ hasNot: cardA });
if (await p.getByRole("dialog").isVisible().catch(() => false)) await p.getByRole("dialog").getByRole("button", { name: /Revoca/ }).click();
await p.waitForTimeout(1200);
out.afterRevokeA = await rpc(A.tok, "tools/list", {}, 9).then(r => r.status + " " + r.raw.slice(0, 120));
sid = {};
out.afterRevokeA_init = await init(A.tok);
out.B_still = (await rpc(B.tok, "tools/list", {}, 10)).status;
save("agents-ui.yml", await p.locator("main").ariaSnapshot());
console.log(JSON.stringify(out, null, 1));
await b.close();

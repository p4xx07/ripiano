import { open, signIn, shot } from "./blib.mjs";
import fs from "node:fs";
const mode = process.argv[2]; // d-en, m-en, m-it, d-it
const mobile = mode.startsWith("m"); const it = mode.endsWith("it");
const { browser, page, errors } = await open(mobile, mobile ? { locale: it ? "it-IT" : "en-US" } : {});
await signIn(page);
// language switch
const langSel = page.getByLabel(/^(Language|Lingua)/);
if (mobile) await page.getByRole("button", { name: /menu/i }).first().click();
console.log("lang selector count:", await langSel.count(), "value:", await langSel.first().inputValue().catch(() => "?"), "options:", await langSel.first().locator("option").allInnerTexts().catch(() => []));
await langSel.first().selectOption(it ? "it" : "en").catch(async (e) => console.log("lang select failed", String(e).slice(0, 100)));
await page.waitForTimeout(500);
const names = await page.locator("nav button:visible, aside button:visible").evaluateAll(els => els.map(e => e.textContent.trim()).filter(Boolean));
console.log("nav:", names.join(" | "));
if (mobile) await page.keyboard.press("Escape");
const out = {};
for (const n of names) {
  if (/Sign out|Esci|menu/i.test(n)) continue;
  try {
    if (mobile) { await page.getByRole("button", { name: /menu/i }).first().click(); await page.waitForTimeout(250); }
    await page.locator("nav, aside").getByRole("button", { name: n, exact: true }).first().click();
    await page.waitForTimeout(1100);
    const m = await page.evaluate(() => {
      const de = document.documentElement; const small = [...document.querySelectorAll("main button, main a, main select, main input:not([type=checkbox]):not([type=radio])")].filter(e => e.offsetParent && (e.getBoundingClientRect().height < 40 || e.getBoundingClientRect().width < 40)).map(e => (e.getAttribute("aria-label") || e.textContent.trim() || e.tagName).slice(0, 25) + ":" + Math.round(e.getBoundingClientRect().width) + "x" + Math.round(e.getBoundingClientRect().height));
      const off = [...document.querySelectorAll("main *")].filter(e => e.offsetParent && e.getBoundingClientRect().right > innerWidth + 2 && e.getBoundingClientRect().width > 0).length;
      return { overflow: de.scrollWidth - innerWidth, small: small.slice(0, 12), smallN: small.length, off, h1: document.querySelector("h1")?.textContent, title: document.title };
    });
    out[n] = (await page.locator("main").innerText()).replace(/\n+/g, " | ");
    console.log(`[${n}] h1="${m.h1}" title="${m.title}" overflowX=${m.overflow} offscreenEls=${m.off} small(<40px)=${m.smallN}`, mobile ? m.small.join(", ") : "");
    await shot(page, `${mode}-scr-${n.replace(/\W+/g, "-").toLowerCase()}`.slice(0, 60), { fullPage: false });
  } catch (e) { console.log(`[${n}] FAIL`, String(e).split("\n")[0].slice(0, 160)); await page.keyboard.press("Escape"); }
}
fs.writeFileSync(`/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judge3/b7-${mode}.json`, JSON.stringify(out, null, 1));
console.log("errors", errors);
await browser.close();

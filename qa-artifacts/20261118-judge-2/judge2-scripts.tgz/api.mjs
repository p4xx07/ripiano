import { launch, login, DESKTOP, ORIGIN } from "./common.mjs";
const b = await launch(); const ctx = await b.newContext(DESKTOP); const p = await ctx.newPage();
await login(p, "it");
const r = await p.request.get(ORIGIN + "/api/documents?limit=20", { headers: { "Accept-Language": "it" } });
const j = await r.json();
for (const d of j.documents) {
  const det = await (await p.request.get(ORIGIN + `/api/documents/${d.id}`)).json();
  console.log(d.id, d.title, "|", JSON.stringify({ sender: det.correspondent, type: det.document_type, date: det.document_date, tags: det.tags, sugg: det.suggestions }).slice(0, 300), "|", (det.text || det.content || "").replace(/\s+/g, " ").slice(0, 200));
}
console.log(Object.keys((await (await p.request.get(ORIGIN + `/api/documents/${j.documents[0].id}`)).json())));
await b.close();

import { launch, login, MOBILE, audit, ART, save, ORIGIN } from "./common.mjs";
import { readFileSync } from "node:fs";
const b = await launch(); const ctx = await b.newContext(MOBILE); const p = await ctx.newPage();
const { code, stamp } = JSON.parse(readFileSync("ids2.json", "utf8"));
await login(p, "it");
// move copy into box via document dialog
const s = p.getByRole("textbox", { name: /Cerca documenti/ });
await s.fill(`sticker:${code}`); await p.waitForTimeout(2500);
console.log("sticker search rows:", await p.locator("article h3").allInnerTexts());
await p.getByRole("button", { name: /^j2cam-/ }).click();
const d = p.getByRole("dialog"); await d.waitFor(); await p.waitForTimeout(1500);
const card = d.locator(".copy-card").first();
await card.locator("select").selectOption({ label: `Scaffale J2 ${stamp} / Scatola J2 ${stamp}` });
await card.getByRole("button", { name: "Sposta" }).click(); await p.waitForTimeout(1500);
console.log("after move:", (await card.innerText()).replace(/\s+/g, " "), "| status:", (await p.locator("[role=status],[role=alert]").allInnerTexts()).filter(Boolean));
// print label
const labelHref = await card.getByRole("link", { name: "Stampa adesivo" }).getAttribute("href");
const lp = await ctx.newPage();
await lp.goto(ORIGIN + labelHref); await lp.waitForTimeout(1500);
console.log("label lang:", await lp.locator("html").getAttribute("lang"), "| text:", (await lp.locator("body").innerText()).replace(/\s+/g, " ").slice(0, 300));
console.log("label imgs:", await lp.evaluate(() => [...document.querySelectorAll("img,svg")].map(e => e.tagName + ":" + (e.getAttribute("alt") ?? e.getAttribute("aria-label") ?? "-")).slice(0, 5)));
const links = await lp.evaluate(() => document.body.innerHTML.match(/https?:\/\/[^"'<\s]+|\?sticker=[^"'<\s]+/g));
console.log("label urls:", links);
await lp.screenshot({ path: ART + "/sticker-label.png" });
await lp.emulateMedia({ media: "print" }); await lp.pdf?.({ path: ART + "/sticker-label-print.pdf" }).catch(() => {});
await lp.close();
await d.getByRole("button", { name: "Chiudi", exact: true }).first().click();
// "scan" the sticker: open the QR target URL
const sp = await ctx.newPage();
await sp.goto(`${ORIGIN}/?sticker=${code}`); await sp.waitForTimeout(3000);
console.log("scan h1:", await sp.getByRole("heading", { level: 1 }).first().innerText(), "| result:", (await sp.locator(".sticker-result").allInnerTexts()).join(" / ").replace(/\s+/g, " "));
await sp.screenshot({ path: ART + "/mobile-sticker-scan.png" });
// lowercase manual lookup
await sp.getByRole("textbox", { name: "Codice adesivo" }).fill(code.toLowerCase().replace("-", ""));
await sp.getByRole("button", { name: "Trova", exact: true }).click(); await sp.waitForTimeout(1500);
console.log("manual lookup (lowercase, no dash):", (await sp.locator(".sticker-result, [role=alert]").allInnerTexts()).join(" / ").replace(/\s+/g, " ").slice(0, 200));
await sp.getByRole("textbox", { name: "Codice adesivo" }).fill("R-ZZZZZZZZ");
await sp.getByRole("button", { name: "Trova", exact: true }).click(); await sp.waitForTimeout(1500);
console.log("bad lookup:", (await sp.locator("[role=alert]").allInnerTexts()).join(" / "));
console.log(await audit(sp));
await b.close();

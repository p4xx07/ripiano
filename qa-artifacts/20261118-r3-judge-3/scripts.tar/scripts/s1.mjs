import fs from "node:fs";
import { judge, Client, upload, waitDoc, FIX, BASE } from "./lib.mjs";
const c = await judge();
const out = {};
const show = (k, r) => console.log(k.padEnd(34), r.s, JSON.stringify(r.d).slice(0, 220));
// unauth
const anon = new Client();
show("anon documents", await anon.j("GET", "/api/documents"));
show("anon agents", await anon.j("GET", "/api/agents"));
show("anon backups", await anon.j("GET", "/api/backups"));
show("anon schema", await anon.j("GET", "/api/schema.json"));
show("anon admin", await anon.j("GET", "/admin/"));
// CSRF: session cookie but no csrf header
const nc = new Client(); nc.cookies = { sessionid: c.cookies.sessionid };
show("no-csrf POST tag", await nc.j("POST", "/api/tags", { name: "j3r3-csrf" }));
show("bad-origin POST tag", await c.j("POST", "/api/tags", { name: "j3r3-csrf2" }, { Origin: "http://evil.example", Referer: "http://evil.example/" }));
// cookies
const lr = await fetch(BASE + "/api/session"); console.log("set-cookie anon:", lr.headers.getSetCookie());
const c2 = new Client(); await c2.raw("GET", "/api/session");
const r2 = await c2.raw("POST", "/api/session", { username: "judge3", password: globalThis.crypto.randomUUID() }); console.log("bad login", r2.status, await r2.text());
// upload validation
const pdf = fs.readFileSync(FIX + "three-pages.pdf"), png = fs.readFileSync(FIX + "judge.png");
show("empty", await upload(c, new Uint8Array(0), "j3r3-empty.pdf"));
show("text as pdf", await upload(c, Buffer.from("hello world"), "j3r3-text.pdf", "application/pdf"));
show("html as png", await upload(c, Buffer.from("<html><script>alert(1)</script></html>"), "j3r3-x.png", "image/png"));
show("svg", await upload(c, Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>'), "j3r3-x.svg", "image/svg+xml"));
show("exe", await upload(c, Buffer.from("MZ\x90\x00binary"), "j3r3-x.exe"));
show("gif", await upload(c, Buffer.from("GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00!\xf9\x04\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;", "latin1"), "j3r3-x.gif", "image/gif"));
show("zip as docx", await upload(c, Buffer.from("PK\x03\x04garbage"), "j3r3-x.docx"));
show("no file", await c.j("POST", "/api/documents", new FormData()));
show("bad scan id", await upload(c, png, "j3r3-a.png", "image/png", { "X-Ripiano-Scan-ID": "nope", "X-Ripiano-Client": "web" }));
let r = await upload(c, Buffer.concat([Buffer.from("%PDF-1.4\n<html><script>alert(document.domain)</script></html>\n")]), "j3r3-polyglot.pdf", "application/pdf"); show("polyglot pdf", r); out.polyglot = r.d.id;
r = await upload(c, pdf, "../../../etc/j3r3-trav<img src=x onerror=alert(1)>.pdf", "application/pdf"); show("traversal+xss name", r); out.xss = r.d.id; console.log("  title:", r.d.title, "| name:", r.d.original_name);
r = await upload(c, png, "j3r3-" + "L".repeat(700) + ".png", "image/png"); show("long name", { s: r.s, d: { t: r.d.title?.length, n: r.d.original_name?.length, e: r.d.error } }); out.long = r.d.id;
// png renamed .pdf (content sniffed)
r = await upload(c, png, "j3r3-png-named.pdf", "application/pdf"); show("png named pdf", { s: r.s, d: { n: r.d.original_name, id: r.d.id } }); out.pngpdf = r.d.id;
// idempotent retry (lost response)
const sid = crypto.randomUUID();
const a = await upload(c, pdf, "j3r3-retry.pdf", "application/pdf", { "X-Ripiano-Scan-ID": sid, "X-Ripiano-Client": "web" });
const b = await upload(c, pdf, "j3r3-retry.pdf", "application/pdf", { "X-Ripiano-Scan-ID": sid, "X-Ripiano-Client": "web" });
console.log("retry same scan id:", a.s, b.s, a.d.id === b.d.id); out.retry = a.d.id;
// concurrent retry
const sid2 = crypto.randomUUID();
const rs = await Promise.all([1, 2, 3, 4].map(() => upload(c, png, "j3r3-race.png", "image/png", { "X-Ripiano-Scan-ID": sid2, "X-Ripiano-Client": "web" })));
console.log("concurrent same scan id:", rs.map(x => x.s), new Set(rs.map(x => x.d.id)).size, rs.map(x=>x.d.error).filter(Boolean)); out.race = rs.find(x=>x.d.id)?.d.id;
// 26MB over limit
const big = Buffer.alloc(26 * 1024 * 1024, 0x20); big.write("%PDF-1.4\n");
r = await upload(c, big, "j3r3-big.pdf", "application/pdf"); show("26MB", r);
for (const k of ["polyglot", "xss", "pngpdf", "retry"]) { const d = await waitDoc(c, out[k]); console.log(k, d.status, JSON.stringify(d.error), d.title); }
// served headers for originals
for (const k of ["polyglot", "xss"]) for (const p of ["original", "archive", "pages/1.png"]) { const x = await c.raw("GET", `/api/documents/${out[k]}/${p}`); console.log(k, p, x.status, x.headers.get("content-type"), "|", x.headers.get("content-disposition"), "|", x.headers.get("content-security-policy"), "|", x.headers.get("x-content-type-options"), x.headers.get("cache-control")); }
fs.writeFileSync("s1-out.json", JSON.stringify(out));

import { launch, MOBILE, ORIGIN } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext(MOBILE)).newPage();
await p.goto(ORIGIN + "/"); await p.waitForTimeout(2000);
console.log(await p.locator("body").ariaSnapshot());
await b.close();

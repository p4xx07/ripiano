import { judge } from "./lib.mjs";
const c = await judge();
const g = (await c.j("GET", "/api/agents")).d.grants.filter(g => !g.revoked_at && /^j3/.test(g.name));
for (const x of g) console.log("revoke", x.name, (await c.j("DELETE", "/api/agents/" + x.id)).s);
console.log("tokens left:", (await c.j("GET", "/api/account/tokens")).d.tokens.length);

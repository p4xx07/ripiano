import { launch, login, audit, englishLeaks, save, MOBILE, DESKTOP, ART, ORIGIN } from "./common.mjs";

const mode = process.argv[2] ?? "mobile";
const browser = await launch();
const ctx = await browser.newContext(mode === "mobile" ? MOBILE : DESKTOP);
const page = await ctx.newPage();
const consoleErr = [];
page.on("console", (m) => { if (m.type() === "error") consoleErr.push(m.text()); });
page.on("pageerror", (e) => consoleErr.push("pageerror " + e.message));

// default language on Italian device
await page.goto(ORIGIN + "/");
await page.locator("select").first().waitFor();
const defaultLang = await page.locator("html").getAttribute("lang");
const signinAudit = await audit(page);
await login(page, "it");
const report = { mode, defaultLang, signinAudit, screens: {} };

const screens = ["Tutti i documenti", "In arrivo", "Da fare", "Etichette e archiviazione", "Archivio cartaceo", "Panoramica", "Flussi di lavoro", "Sicurezza", "Email", "Sorgenti", "Condivisi con me", "Cestino", "Agenti", "Persone", "Backup"];
for (const name of screens) {
  const menu = page.getByRole("button", { name: "Apri o chiudi il menu" });
  if (await menu.isVisible()) { await menu.click(); await page.waitForTimeout(300); }
  const btn = page.getByRole("button", { name, exact: true });
  if (!(await btn.count())) { report.screens[name] = { missing: true }; if (await page.getByRole("button", { name: "Chiudi la navigazione" }).isVisible().catch(() => false)) await page.getByRole("button", { name: "Chiudi la navigazione" }).click(); continue; }
  await btn.first().click();
  await page.waitForTimeout(1500);
  const h1 = await page.getByRole("heading", { level: 1 }).first().textContent().catch(() => null);
  const a = await audit(page);
  const en = await englishLeaks(page);
  const snap = await page.locator("main").ariaSnapshot().catch((e) => "ERR " + e.message);
  report.screens[name] = { h1, audit: a, english: en };
  save(`snap-${mode}-${name.replace(/\W+/g, "_")}.yml`, snap);
  if (mode === "mobile") await page.screenshot({ path: `${ART}/${mode}-${name.replace(/\W+/g, "_")}.png`, fullPage: mode === "mobile" ? false : false });
}
report.consoleErr = consoleErr;
save(`tour-${mode}.json`, report);
console.log(JSON.stringify(report, null, 1).slice(0, 20000));
await browser.close();

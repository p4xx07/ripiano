import fs from "node:fs";
import { judge, Client, upload, waitDoc, FIX, BASE, sleep } from "./lib.mjs";
const c = await judge();
const S = (x) => JSON.stringify(x).slice(0, 400);
const s1 = JSON.parse(fs.readFileSync("s1-out.json"));
// backup
let r = await c.j("POST", "/api/backups", {}); console.log("backup start", r.s, S(r.d)); const bid = r.d.id ?? r.d.run?.id;
r = await c.j("POST", "/api/backups", {}); console.log("backup 2nd concurrent", r.s, S(r.d));
for (let i = 0; i < 60; i++) { await sleep(2000); const l = await c.j("GET", "/api/backups"); const run = l.d.runs.find(x => x.id === bid) ?? l.d.runs[0]; if (run.status !== "queued" && run.status !== "running" && run.status !== "pending") { console.log("backup end", (i + 1) * 2 + "s", S(run)); break; } }
r = await c.j("GET", "/api/backups"); console.log("runs", r.d.runs.slice(0, 4).map(x => [x.status, x.trigger, x.snapshot_name, x.error]), Object.keys(r.d));
// failed doc retry
r = await c.j("POST", `/api/documents/${s1.polyglot}/retry`); console.log("retry failed", r.s, S(r.d).slice(0, 120));
let d = await waitDoc(c, s1.polyglot); console.log(" ->", d.status, d.error);
r = await c.j("POST", `/api/documents/${s1.polyglot}/retry`); r = await c.j("POST", `/api/documents/${s1.polyglot}/retry`); console.log("double retry", r.s, S(r.d).slice(0, 160));
// upload + immediately cancel, then requeue
r = await upload(c, fs.readFileSync(FIX + "barcode-batch-desktop.pdf"), "j3r3-cancel.pdf"); const cid = r.d.id;
r = await c.j("POST", `/api/documents/${cid}/cancel-processing`); console.log("cancel", r.s, S(r.d).slice(0, 200));
d = (await c.j("GET", "/api/documents/" + cid)).d; console.log(" state", d.status, d.error);
r = await c.j("POST", `/api/documents/${cid}/retry`); console.log("retry after cancel", r.s); d = await waitDoc(c, cid); console.log(" ->", d.status, d.error, d.title);
const o1 = await c.raw("GET", `/api/documents/${cid}/original`); const ob = Buffer.from(await o1.arrayBuffer()); console.log("original intact", ob.equals(fs.readFileSync(FIX + "barcode-batch-desktop.pdf")));
// reprocess while keeping original
r = await c.j("POST", `/api/documents/${s1.retry}/reprocess`); console.log("reprocess", r.s); r = await c.j("POST", `/api/documents/${s1.retry}/reprocess`); console.log("reprocess again while busy", r.s, S(r.d).slice(0, 120)); d = await waitDoc(c, s1.retry); console.log(" ->", d.status);
r = await c.j("GET", "/api/jobs"); console.log("jobs", S(r.d).slice(0, 600));
r = await c.j("GET", "/api/documents?view=exceptions"); console.log("exceptions", r.d.documents.length, r.d.documents.slice(0, 8).map(x => [x.title.slice(0, 25), x.status, !!x.duplicate_of]));

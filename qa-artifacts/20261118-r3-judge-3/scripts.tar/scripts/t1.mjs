import { judge, Client, BASE } from "./lib.mjs";
const c = await judge();
console.log(await c.j("GET","/api/session").then(r=>r.d));
const r = await c.raw("GET","/");
console.log(r.status, Object.fromEntries(r.headers));
const a = await c.raw("GET","/api/documents");
console.log(a.status, Object.fromEntries(a.headers));
const d = await a.json(); console.log(Object.keys(d), d.documents?.length ?? d.results?.length, JSON.stringify(d).slice(0,1500));
for (const p of ["/api/agents","/api/account/tokens","/api/people","/api/backups","/api/overview"]) { const x = await c.j("GET",p); console.log(p, x.s, JSON.stringify(x.d).slice(0,800)); }

import { launch, login, MOBILE, ART } from "./common.mjs";
for (const [w, h] of [[320, 640], [375, 667], [390, 844]]) {
const b = await launch(); const p = await (await b.newContext({ ...MOBILE, viewport: { width: w, height: h } })).newPage();
await login(p, "it");
await p.getByRole("button", { name: "Apri o chiudi il menu" }).click(); await p.waitForTimeout(600);
const info = await p.evaluate(() => { const side = document.querySelector(".sidebar"); const cs = getComputedStyle(side); const btns = [...side.querySelectorAll(".nav-link")]; const last = btns[btns.length - 1].getBoundingClientRect(); const hit = btns.map(b2 => { const r = b2.getBoundingClientRect(); const e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return b2.textContent.trim() + (e && (e === b2 || b2.contains(e)) ? "" : " [COVERED by " + (e?.textContent?.trim().slice(0, 20)) + "]"); }); return { overflowY: cs.overflowY, sh: side.scrollHeight, ch: side.clientHeight, lastBottom: Math.round(last.bottom), hit: hit.filter(x => x.includes("COVERED")) }; });
console.log(w, h, JSON.stringify(info));
if (w === 320) await p.screenshot({ path: ART + "/mobile320-menu.png" });
await b.close();
}

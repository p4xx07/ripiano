import { launch, login, DESKTOP, ART, save } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext(DESKTOP)).newPage();
await login(p, "it");
await p.getByRole("button", { name: "Backup", exact: true }).click(); await p.waitForTimeout(1500);
const t0 = Date.now();
await p.getByRole("button", { name: "Esegui backup ora" }).click(); await p.waitForTimeout(1500);
console.log("status:", (await p.locator("[role=status],[role=alert]").allInnerTexts()).filter(Boolean));
for (let i = 0; i < 36; i++) {
  await p.waitForTimeout(5000); await p.reload(); await p.waitForTimeout(1200);
  await p.getByRole("button", { name: "Backup", exact: true }).click(); await p.waitForTimeout(1200);
  const first = (await p.locator("main h3").first().innerText()) + " | " + (await p.locator("main h3").first().evaluate(h => h.parentElement.innerText.replace(/\s+/g, " ").slice(0, 200)));
  if (/completato|non riuscito/.test(first) && Date.now() - t0 > 6000) { console.log("after", (Date.now() - t0) / 1000, "s:", first); break; }
  if (i % 6 == 0) console.log("..", first);
}
await p.screenshot({ path: ART + "/desktop-backup.png" });
await b.close();

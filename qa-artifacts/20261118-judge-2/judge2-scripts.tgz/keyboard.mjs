import { launch, login, DESKTOP, MOBILE, audit, ART, save } from "./common.mjs";
const mode = process.argv[2] ?? "desktop";
const b = await launch(); const p = await (await b.newContext(mode === "desktop" ? DESKTOP : { ...MOBILE })).newPage();
await login(p, "it");
const focusInfo = () => p.evaluate(() => {
  const e = document.activeElement; if (!e) return null;
  const cs = getComputedStyle(e);
  return { tag: e.tagName, name: (e.getAttribute("aria-label") || e.textContent || "").trim().slice(0, 60), outline: cs.outlineStyle + " " + cs.outlineWidth + " " + cs.outlineColor, shadow: cs.boxShadow.slice(0, 60), inDialog: !!e.closest("[role=dialog]") };
});
const log = (...a) => console.log(...a);
// Tab order from top
await p.reload(); await p.waitForTimeout(1500);
const seq = [];
for (let i = 0; i < 25; i++) { await p.keyboard.press("Tab"); seq.push(await focusInfo()); }
log("TAB ORDER:", seq.map(f => `${f.tag}:${f.name}${/none|0px/.test(f.outline) && f.shadow === "none" ? " [NO VISIBLE FOCUS]" : ""}`).join("\n  "));
// nav semantics
log("nav landmarks:", await p.evaluate(() => [...document.querySelectorAll("nav")].map(n => n.getAttribute("aria-label")), ), "aria-current:", await p.evaluate(() => [...document.querySelectorAll("[aria-current]")].map(e => e.textContent.trim() + "=" + e.getAttribute("aria-current"))));
// skip link
await p.reload(); await p.waitForTimeout(1500);
await p.keyboard.press("Tab"); log("first tab:", await focusInfo());
await p.keyboard.press("Enter"); await p.waitForTimeout(300); await p.keyboard.press("Tab"); log("after skip+tab:", await focusInfo());
// shortcuts
await p.locator("body").click({ position: { x: 5, y: 5 } }).catch(() => {});
await p.keyboard.press("Escape");
await p.evaluate(() => document.activeElement?.blur());
await p.keyboard.press("?"); await p.waitForTimeout(500);
const help = p.getByRole("dialog");
if (await help.isVisible()) { save(`kbd-help-${mode}.yml`, await help.ariaSnapshot()); await p.screenshot({ path: `${ART}/${mode}-shortcuts.png` }); log("help focus:", await focusInfo()); await p.keyboard.press("Escape"); await p.waitForTimeout(300); log("help closed:", !(await help.isVisible())); }
else log("? did not open help");
await p.keyboard.press("/"); log("after /:", await focusInfo());
await p.keyboard.type("9473"); await p.waitForTimeout(2500);
log("live regions after search:", await p.evaluate(() => [...document.querySelectorAll("[aria-live],[role=status]")].map(e => e.textContent.trim().slice(0, 80)).filter(Boolean)));
await p.keyboard.press("Escape"); await p.evaluate(() => document.activeElement?.blur());
await p.keyboard.press("j"); await p.waitForTimeout(300); log("after j:", await focusInfo());
await p.keyboard.press("j"); await p.waitForTimeout(300); log("after j j:", await focusInfo());
await p.keyboard.press("k"); await p.waitForTimeout(300); log("after k:", await focusInfo());
const opener = await focusInfo();
await p.keyboard.press("Enter"); await p.waitForTimeout(1500);
log("dialog open:", await p.getByRole("dialog").isVisible(), "focus:", await focusInfo());
// focus trap: tab 80 times, check all in dialog
let escaped = 0; const noFocus = new Set();
for (let i = 0; i < 80; i++) { await p.keyboard.press("Tab"); const f = await focusInfo(); if (!f?.inDialog) escaped++; if (/none|0px/.test(f.outline) && f.shadow === "none") noFocus.add(f.tag + ":" + f.name); }
log("tabs escaping dialog:", escaped, "no visible focus:", [...noFocus].slice(0, 15));
await p.keyboard.press("Escape"); await p.waitForTimeout(500);
log("after Esc dialog visible:", await p.getByRole("dialog").isVisible(), "focus returned to:", await focusInfo(), "opener was:", opener?.name);
// N opens Add
await p.evaluate(() => document.activeElement?.blur());
await p.keyboard.press("n"); await p.waitForTimeout(500);
log("N add dialog:", await p.getByRole("dialog").getAttribute("aria-label").catch(() => null), await p.getByRole("dialog").locator("h2").innerText().catch(() => "-"), "focus", await focusInfo());
await p.keyboard.press("Tab"); log(" tab1:", await focusInfo());
await p.keyboard.press("Tab"); log(" tab2:", await focusInfo());
await p.keyboard.press("Escape"); await p.waitForTimeout(300);
// g + letters
for (const k of ["i", "a", "t", "o", "p"]) { await p.evaluate(() => document.activeElement?.blur()); await p.keyboard.press("g"); await p.keyboard.press(k); await p.waitForTimeout(800); log("g", k, "->", await p.getByRole("heading", { level: 1 }).first().innerText(), "| focus:", (await focusInfo())?.tag, "| title:", await p.title()); }
await b.close();

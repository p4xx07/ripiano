import { judge } from "./lib.mjs";
const c = await judge(); const H = { "Accept-Language": "it" };
let r = await c.j("GET", "/api/documents?view=exceptions", undefined, H); console.log("exceptions:", r.d.documents.filter(d => d.error).slice(0, 2).map(d => d.error));
r = await c.j("GET", "/api/jobs", undefined, H); console.log("jobs:", r.d.documents_failed.items.slice(0, 2).map(d => d.error));
r = await c.j("GET", "/api/overview", undefined, H); console.log("overview keys:", Object.keys(r.d), JSON.stringify(r.d.attention ?? r.d.needs_look ?? "").slice(0, 300));

import { open, signIn, shot } from "./blib.mjs";
const { browser, page } = await open(false);
await signIn(page); await page.waitForTimeout(800);
console.log(await page.locator("h1").innerText(), "| lang:", await page.evaluate(() => [document.documentElement.lang, navigator.language, JSON.stringify(localStorage)]));
console.log(await page.getByRole("button").evaluateAll(e => e.slice(0, 22).map(x => x.textContent.trim().slice(0, 20))));
await browser.close();

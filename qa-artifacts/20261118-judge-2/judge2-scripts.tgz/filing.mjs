import { launch, login, MOBILE, audit, ART, FIX, save } from "./common.mjs";
import { readFileSync } from "node:fs";
const b = await launch(); const p = await (await b.newContext(MOBILE)).newPage();
p.on("dialog", async (dl) => { console.log("NATIVE DIALOG", dl.type(), dl.message()); await dl.accept(); });
const stamp = JSON.parse(readFileSync("capture.json", "utf8")).stamp;
await login(p, "it");
async function nav(name) {
  const menu = p.getByRole("button", { name: "Apri o chiudi il menu" });
  if (await menu.isVisible()) { await menu.click(); await p.waitForTimeout(300); }
  await p.getByRole("button", { name, exact: true }).first().click(); await p.waitForTimeout(1200);
}
const tag = `Bollette J2 ${stamp}`;
await nav("Etichette e archiviazione");
await p.getByPlaceholder("es. Bollette").fill(tag);
await p.getByPlaceholder("fattura, luce, bolletta").fill("lampone");
await p.getByRole("button", { name: "Crea etichetta" }).click(); await p.waitForTimeout(1500);
console.log("tag created visible:", await p.getByRole("heading", { name: tag }).isVisible());
console.log("status:", (await p.locator("[role=status],[role=alert]").allInnerTexts()).filter(Boolean));

await nav("Tutti i documenti");
const s = p.getByRole("textbox", { name: /Cerca documenti/ });
await s.fill("j2cam"); await p.waitForTimeout(2000);
await p.getByRole("button", { name: /^j2cam-/ }).click();
let d = p.getByRole("dialog"); await d.waitFor(); await p.waitForTimeout(800);
await d.getByRole("button", { name: "Aggiungi un mittente" }).click();
await d.getByRole("textbox", { name: "Nome del nuovo mittente" }).fill(`Comune di Esempio J2 ${stamp}`);
await d.getByRole("button", { name: "Aggiungi mittente", exact: true }).click(); await p.waitForTimeout(1000);
console.log("sender selected:", await d.getByRole("combobox", { name: /^Mittente/ }).evaluate(e => e.selectedOptions[0]?.textContent));
console.log("focus after add sender:", await p.evaluate(() => document.activeElement?.outerHTML.slice(0,100)));
await d.getByRole("button", { name: "Aggiungi un tipo" }).click();
await d.getByRole("textbox", { name: /Nome del nuovo tipo/ }).fill(`Avviso J2 ${stamp}`);
await d.getByRole("button", { name: /^Aggiungi tipo$/ }).click(); await p.waitForTimeout(1000);
await d.getByRole("textbox", { name: /^Data del documento/ }).fill("2026-04-15");
await d.getByRole("checkbox", { name: new RegExp(tag) }).check();
await d.getByRole("button", { name: "Salva modifiche" }).click(); await p.waitForTimeout(1500);
console.log("after save status:", (await p.locator("[role=status],[role=alert]").allInnerTexts()).filter(Boolean), "dialog open:", await d.isVisible());
await p.screenshot({ path: ART + "/mobile-filed.png" });
if (await d.isVisible()) await d.getByRole("button", { name: "Chiudi", exact: true }).first().click();

await s.fill("j2gal"); await p.waitForTimeout(2000);
await p.getByRole("button", { name: /^j2gal-/ }).click();
d = p.getByRole("dialog"); await d.waitFor(); await p.waitForTimeout(2500);
save("gal-dialog.yml", await d.ariaSnapshot());
await p.screenshot({ path: ART + "/mobile-suggestions.png" });
await d.getByRole("button", { name: "Chiudi", exact: true }).first().click();

// re-upload eml for rule-based filing
await p.getByRole("button", { name: "Aggiungi", exact: true }).click();
const ch = p.waitForEvent("filechooser");
const resp = p.waitForResponse((r) => r.url().endsWith("/api/documents") && r.request().method() === "POST");
await p.getByRole("dialog").getByRole("button", { name: /^Sfoglia i file/ }).click();
await (await ch).setFiles({ name: `j2eml2-${stamp}.eml`, mimeType: "message/rfc822", buffer: readFileSync(`${FIX}/email-notice.eml`) });
const id = (await (await resp).json()).id;
console.log("eml2 id", id);
await p.waitForTimeout(15000);
const det = await (await p.request.get(`http://localhost:18080/api/documents/${id}`)).json();
console.log("eml2:", det.status, JSON.stringify(det.tags), det.correspondent, det.duplicate_of);
save("ids.json", { eml2: id, tag });
await b.close();

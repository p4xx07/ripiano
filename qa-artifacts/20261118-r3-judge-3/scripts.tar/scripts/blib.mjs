import { createRequire } from "node:module";
import { pw, BASE } from "./lib.mjs";
const require = createRequire("/Users/debotta/dbrepos/ripiano/apps/web/");
export const { chromium, devices } = require("@playwright/test");
export const SHOTS = "/Users/debotta/dbrepos/ripiano/qa-artifacts/20261118-r3-judge-3/";
export async function open(mobile = false, opts = {}) {
  const browser = await chromium.launch({ channel: "chrome", headless: true });
  const context = await browser.newContext(mobile ? { locale: opts.locale || "en-US", viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, ...opts } : { locale: "en-US", viewport: { width: 1440, height: 900 }, ...opts });
  const page = await context.newPage(); page.setDefaultTimeout(opts.timeout || 7000);
  const errors = [];
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text().slice(0, 200)); });
  page.on("pageerror", (e) => errors.push("pageerror: " + String(e).slice(0, 200)));
  page.on("dialog", (d) => { errors.push("DIALOG: " + d.message()); d.dismiss(); });
  return { browser, context, page, errors };
}
export async function signIn(page, user = "judge3", password = pw()) {
  await page.goto(BASE + "/");
  await page.getByLabel(/Username|Nome utente/).fill(user);
  await page.getByLabel(/^Password/).fill(password);
  await page.getByRole("button", { name: /Sign in|Accedi/ }).click();
  await page.getByRole("heading", { level: 1 }).first().waitFor();
}
export async function nav(page, name) {
  const menu = page.getByRole("button", { name: /Toggle menu|menu/i }).first();
  if (await menu.isVisible().catch(() => false)) await menu.click();
  await page.getByRole("button", { name, exact: true }).first().click();
  await page.waitForTimeout(700);
}
export const shot = (page, name, o = {}) => page.screenshot({ path: SHOTS + name + ".png", ...o });

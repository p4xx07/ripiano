import { launch, login, DESKTOP, ART } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext(DESKTOP)).newPage();
await login(p, "it");
await p.getByRole("textbox", { name: /Cerca documenti/ }).fill("9473"); await p.waitForTimeout(2500);
const t = p.getByRole("button", { name: /^j2cam-/ }); await t.focus(); await p.keyboard.press("Enter"); await p.waitForTimeout(1500);
for (let i = 0; i < 80; i++) { await p.keyboard.press("Tab"); const f = await p.evaluate(() => { const e = document.activeElement; const cs = getComputedStyle(e); return { t: e.tagName, type: e.type, l: e.getAttribute("aria-label"), o: cs.outlineStyle, s: cs.boxShadow }; }); if (f.o === "none" && f.s === "none") { console.log("no focus ring:", JSON.stringify(f)); await p.screenshot({ path: ART + "/desktop-focus-missing.png" }); break; } }
await p.keyboard.press("Escape"); await p.waitForTimeout(500);
console.log("focus after close:", await p.evaluate(() => document.activeElement?.outerHTML.slice(0, 80)));
// contrast sample: muted text
console.log(await p.evaluate(() => { const r = []; for (const sel of [".document-row small", ".eyebrow", "p", ".text-action", ".document-snippet", "label small", ".field-hint"]) { const e = document.querySelector(sel); if (!e) continue; const cs = getComputedStyle(e); r.push(sel + " " + cs.color + " on " + (() => { let n = e; while (n && getComputedStyle(n).backgroundColor === "rgba(0, 0, 0, 0)") n = n.parentElement; return n ? getComputedStyle(n).backgroundColor : "?"; })() + " " + cs.fontSize); } return r; }));
// zoom / reflow: 320 css px
await p.setViewportSize({ width: 320, height: 640 }); await p.waitForTimeout(800);
console.log("reflow 320 overflow:", await p.evaluate(() => document.documentElement.scrollWidth));
await b.close();

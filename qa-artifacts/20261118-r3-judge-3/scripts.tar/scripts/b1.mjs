import { open, signIn, nav, shot } from "./blib.mjs";
for (const mobile of [false, true]) {
  const { browser, page, errors } = await open(mobile);
  await signIn(page);
  const tag = mobile ? "m" : "d";
  await page.waitForTimeout(1000);
  await shot(page, `${tag}-01-library`);
  const btns = await page.getByRole("button").evaluateAll(els => els.filter(e => e.offsetParent).map(e => (e.getAttribute("aria-label") || e.textContent).trim().slice(0, 30)));
  console.log(tag, "library buttons:", [...new Set(btns)].slice(0, 70).join(" | "));
  if (mobile) { await page.getByRole("button", { name: /Toggle menu/ }).click(); await page.waitForTimeout(400); await shot(page, "m-02-menu"); const nb = await page.locator("nav button, aside button").evaluateAll(els => els.filter(e => e.offsetParent).map(e => e.textContent.trim())); console.log("mobile nav:", nb.join(" | ")); }
  else { const nb = await page.locator("nav button, aside button").evaluateAll(els => els.filter(e => e.offsetParent).map(e => e.textContent.trim())); console.log("desktop nav:", nb.join(" | ")); }
  console.log(tag, "errors:", errors);
  await browser.close();
}

import { open, signIn, nav, shot } from "./blib.mjs";
import { FIX } from "./lib.mjs";
import fs from "node:fs";
const { browser, page, errors, context } = await open(true, { locale: "it-IT" });
const step = async (name, fn) => { try { await fn(); } catch (e) { console.log("FAIL", name, String(e).split("\n")[0].slice(0, 200)); await shot(page, "fail-m-" + name.replace(/\W+/g, "-")).catch(() => {}); } };
await signIn(page); await page.waitForTimeout(800);
const stamp = Date.now() % 1000000;
await page.getByRole("button", { name: "Aggiungi", exact: true }).click(); await page.waitForTimeout(500); await shot(page, "m-it-03-add-dialog");
console.log("file inputs:", await page.locator("input[type=file]").evaluateAll(els => els.map(e => ({ accept: e.accept, capture: e.getAttribute("capture"), multiple: e.multiple }))));
const dlgBox = await page.getByRole("dialog").boundingBox(); console.log("add dialog box:", dlgBox);
await step("camera", async () => { const ch = page.waitForEvent("filechooser"); await page.getByRole("button", { name: /Scatta una foto/ }).click(); await (await ch).setFiles([{ name: `j3m-${stamp}-foto.png`, mimeType: "image/png", buffer: fs.readFileSync(FIX + "judge.png") }]); await page.waitForTimeout(3500); await shot(page, "m-it-04-after-photo"); console.log("after photo:", (await page.locator("main").innerText()).split("\n").filter(l => /Aggiunt|caric|j3m-/i.test(l)).slice(0, 5).join(" || ")); console.log("scrollY:", await page.evaluate(() => scrollY)); });
await step("gallery", async () => { await page.getByRole("button", { name: "Aggiungi", exact: true }).click(); const ch = page.waitForEvent("filechooser"); await page.getByRole("button", { name: /Scegli dalle foto/ }).click(); await (await ch).setFiles([{ name: `j3m-${stamp}-galleria.jpg`, mimeType: "image/jpeg", buffer: fs.readFileSync(FIX + "judge.png") }]); await page.waitForTimeout(3000); });
await page.waitForTimeout(6000);
await step("open doc", async () => { await page.getByRole("button", { name: `j3m-${stamp}-foto`, exact: true }).first().tap(); await page.waitForTimeout(1200); await shot(page, "m-it-05-doc-dialog"); const dlg = page.getByRole("dialog"); const m = await page.evaluate(() => { const d = document.querySelector("[role=dialog]"); return { w: d.getBoundingClientRect().width, sw: d.scrollWidth, cw: d.clientWidth, small: [...d.querySelectorAll("button, a, select, input:not([type=checkbox])")].filter(e => e.offsetParent && (e.getBoundingClientRect().height < 40 || e.getBoundingClientRect().width < 40)).map(e => (e.getAttribute("aria-label") || e.textContent.trim() || e.tagName).slice(0, 28) + ":" + Math.round(e.getBoundingClientRect().width) + "x" + Math.round(e.getBoundingClientRect().height)) }; }); console.log("mobile dialog:", JSON.stringify(m)); await dlg.getByLabel(/Data del documento/).fill("2026-10-01"); await dlg.getByRole("button", { name: /Salva modifiche/ }).scrollIntoViewIfNeeded(); await shot(page, "m-it-06-doc-dialog-save"); await dlg.getByRole("button", { name: /Salva modifiche/ }).tap(); await page.waitForTimeout(1200); console.log("after save dialog open:", await dlg.count(), "| toast:", await page.locator("[role=status]:visible").allInnerTexts()); await shot(page, "m-it-07-after-save"); });
// mobile search
await step("search", async () => { if (await page.getByRole("dialog").count()) await page.keyboard.press("Escape"); await page.getByPlaceholder(/Cerca testo/).fill("mirtillo"); await page.waitForTimeout(1200); await shot(page, "m-it-08-search"); });
// mobile agents + paper
await nav(page, "Agenti"); await page.waitForTimeout(700); await shot(page, "m-it-09-agents"); 
await nav(page, "Etichette e archiviazione"); await page.waitForTimeout(700); await page.getByText("Mittenti e organizzazioni").scrollIntoViewIfNeeded(); await shot(page, "m-it-10-senders-small-buttons");
await nav(page, "Persone"); await page.waitForTimeout(700); await shot(page, "m-it-11-people");
console.log("errors", errors);
await browser.close();

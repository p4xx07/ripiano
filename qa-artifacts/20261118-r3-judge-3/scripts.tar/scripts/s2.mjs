import fs from "node:fs";
import { judge, Client, upload, waitDoc, FIX, BASE, mcp, tool } from "./lib.mjs";
const c = await judge();
const o = JSON.parse(fs.readFileSync("s1-out.json"));
const S = (x) => JSON.stringify(x).slice(0, 330);
const mk = async (name) => { const r = await c.j("POST", "/api/tags", { name }); if (r.s >= 300) { const l = await c.j("GET", "/api/tags"); return l.d.tags.find(t => t.name === name).id; } return r.d.id; };
const TA = await mk("j3r3-A"), TB = await mk("j3r3-B"), TP = await mk("j3r3-plain");
let r = await upload(c, fs.readFileSync(FIX + "office-letter.docx"), "j3r3-letter.docx"); const dLetter = r.d.id;
r = await upload(c, fs.readFileSync(FIX + "email-notice.eml"), "j3r3-mail.eml"); const dMail = r.d.id;
const L = await waitDoc(c, dLetter), M = await waitDoc(c, dMail);
console.log("letter", L.status, L.title, "| mail", M.status, M.title);
const dPdf = o.retry, dPng = o.pngpdf;
const bt = (ids, tag, action = "add") => c.j("POST", "/api/documents/bulk-tags", { document_ids: ids, tag_id: tag, action });
console.log("tag A->letter", (await bt([dLetter], TA)).s, "B->mail", (await bt([dMail], TB)).s);
const grant = async (name, scopes, filter) => { const r = await c.j("POST", "/api/agents", { name, scopes, expires_in_days: 1, ...(filter ? { filter_tag_id: filter } : {}) }); if (r.s !== 201) console.log("GRANT FAIL", name, r.s, r.d); return r.d; };
const sfx = Date.now() % 100000;
const gA = await grant("j3r3-A-reader-" + sfx, ["documents:search", "documents:text"], TA);
const gB = await grant("j3r3-B-tagger-" + sfx, ["documents:search", "documents:tag"], null);
const gC = await grant("j3r3-C-cloud-" + sfx, ["documents:search"], null);
const gD = await grant("j3r3-D-tagB-" + sfx, ["documents:tag", "documents:filing", "documents:search"], TB);
fs.writeFileSync("s2-out.json", JSON.stringify({ TA, TB, TP, dLetter, dMail, dPdf, dPng, gA, gB, gC, gD }));
for (const [n, g] of [["A", gA], ["B", gB], ["C", gC], ["D", gD]]) { const t = await mcp(g.token, "tools/list"); console.log("tools", n, t.s, t.d.result?.tools?.map(x => x.name)); }
// init
r = await mcp(gA.token, "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "j3", version: "1" } }); console.log("init", r.s, S(r.d));
// text of letter via A
r = await tool(gA.token, "get_document_text", { document_id: dLetter }); console.log("A text letter", r.err, S(r.r)); const phrase = (r.r.text || "").split(/\s+/).filter(w => w.length > 6)[3]; console.log("phrase:", phrase);
r = await tool(gA.token, "search_documents", {}); console.log("A search all ->", r.r.documents?.map(d => d.title));
r = await tool(gA.token, "get_document_text", { document_id: dMail }); console.log("A text mail (outside filter)", r.err, S(r.r));
r = await tool(gA.token, "get_document_text", { document_id: dPdf }); console.log("A text pdf (outside filter)", r.err, S(r.r));
r = await tool(gA.token, "change_document_tags", { document_id: dMail, add: [TA] }); console.log("A change tags (no scope)", r.err, S(r.r));
// C cloud: no text
r = await tool(gC.token, "get_document_text", { document_id: dLetter }); console.log("C get text", r.err, S(r.r));
r = await tool(gC.token, "semantic_search", { query: "letter" }); console.log("C semantic", r.err, S(r.r));
r = await tool(gC.token, "search_documents", { query: phrase }); console.log("C search OCR phrase", r.err, r.r.documents?.length);
r = await tool(gC.token, "search_documents", { query: "j3r3-letter" }); console.log("C search title", r.err, S(r.r));
r = await tool(gA.token, "search_documents", { query: phrase }); console.log("A search OCR phrase", r.err, r.r.documents?.map(d => d.title));
// B tries to widen A
r = await tool(gB.token, "change_document_tags", { document_id: dMail, add: [TA] }); console.log("B add A-filter tag to mail", r.err, S(r.r));
r = await tool(gB.token, "change_document_tags", { document_id: dLetter, remove: [TA] }); console.log("B remove A-filter tag", r.err, S(r.r));
r = await tool(gB.token, "change_document_tags", { document_id: dMail, add: [TB] }); console.log("B add D-filter tag", r.err, S(r.r));
r = await tool(gB.token, "change_document_tags", { document_id: dMail, add: [TP] }); console.log("B add plain", r.err, S(r.r));
r = await tool(gB.token, "change_document_tags", { document_id: dMail, add: [TP, TA] }); console.log("B add mixed", r.err, S(r.r));
r = await tool(gB.token, "list_tags"); console.log("B list_tags n=", r.r.tags?.length);
// D (filter TB): reach outside
r = await tool(gD.token, "change_document_tags", { document_id: dLetter, add: [TB] }); console.log("D tag doc outside grant", r.err, S(r.r));
r = await tool(gD.token, "change_document_tags", { document_id: dMail, add: [TA] }); console.log("D add A tag on own doc", r.err, S(r.r));
r = await tool(gD.token, "change_document_tags", { document_id: dMail, remove: [TB] }); console.log("D remove own filter tag", r.err, S(r.r));
r = await tool(gD.token, "search_documents", {}); console.log("D search after self-narrow", r.r.documents?.length);
console.log("restore B tag", (await bt([dMail], TB)).s);
// malformed
r = await tool(gB.token, "search_documents", { query: 5 }); console.log("bad arg", r.err, S(r.r));
r = await tool(gB.token, "search_documents", { query: "x", extra: 1 }); console.log("extra arg", r.err, S(r.r));
r = await tool(gB.token, "nope", {}); console.log("unknown tool", r.err, S(r.r));
r = await tool(gB.token, "get_document_text", { document_id: "' OR 1=1 --" }); console.log("sqli", r.err, S(r.r));
// auth edge
console.log("no token", (await mcp(null, "tools/list")).s, "garbage", (await mcp("rpa_garbage", "tools/list")).s);
r = await mcp(gA.token, "tools/list", {}, { Origin: "http://evil.example" }); console.log("evil origin", r.s, S(r.d));
r = await mcp(gA.token, "tools/list", {}, { Host: "evil.example" }); console.log("evil host", r.s, S(r.d));
const ac = new Client(); ac.bearer = gA.token; console.log("agent token on /api", (await ac.j("GET", "/api/documents")).s);
r = await fetch(BASE + "/api/documents", { headers: { Authorization: "Token " + gA.token } }); console.log("agent token as API Token", r.status);
// trash hides
await c.j("POST", `/api/documents/${dLetter}/trash`); r = await tool(gA.token, "get_document_text", { document_id: dLetter }); console.log("A text of trashed", r.err, S(r.r)); console.log("restore", (await c.j("POST", `/api/documents/${dLetter}/restore`)).s);
// delete filter tag
r = await c.j("DELETE", "/api/tags/" + TA); console.log("delete filter tag", r.s, S(r.d));
// revoke A
r = await c.j("DELETE", "/api/agents/" + gA.id); console.log("revoke A", r.s);
r = await mcp(gA.token, "tools/list"); console.log("A after revoke", r.s, S(r.d), r.h.get("www-authenticate"));
r = await tool(gB.token, "change_document_tags", { document_id: dMail, add: [TA] }); console.log("B add A tag after A revoked", r.err, S(r.r));
await bt([dMail], TA, "remove");
r = await c.j("GET", "/api/agents/events"); console.log("events", r.d.events.length); for (const e of r.d.events.slice(0, 40)) console.log("  ", e.agent, e.action, e.outcome, e.document_id?.slice(0, 8));
r = await c.j("GET", "/api/agents"); console.log(S(r.d.grants.filter(g => g.name.startsWith("j3r3")).map(g => [g.name, g.revoked_at ? "revoked" : "active", g.last_used_at ? "used" : "unused"])));

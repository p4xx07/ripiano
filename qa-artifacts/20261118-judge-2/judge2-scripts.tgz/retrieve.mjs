import { launch, login, MOBILE, audit, ART, save } from "./common.mjs";
import { readFileSync } from "node:fs";
const b = await launch(); const ctx = await b.newContext(MOBILE); const p = await ctx.newPage();
p.on("dialog", async (dl) => { console.log("NATIVE DIALOG", dl.type(), dl.message()); await dl.accept(); });
const stamp = JSON.parse(readFileSync("capture.json", "utf8")).stamp;
const { tag, eml2 } = JSON.parse(readFileSync("ids.json", "utf8"));
await login(p, "it");
async function nav(name) {
  const menu = p.getByRole("button", { name: "Apri o chiudi il menu" });
  if (await menu.isVisible()) { await menu.click(); await p.waitForTimeout(300); }
  await p.getByRole("button", { name, exact: true }).first().click(); await p.waitForTimeout(1200);
}
const s = p.getByRole("textbox", { name: /Cerca documenti/ });
const rows = async () => p.locator("article").evaluateAll(a => a.map(x => x.querySelector("h3")?.innerText));
// correction: open gal, tap sender suggestion
let d;
if (0) console.log("after tap suggestion: sender=", await d.getByRole("combobox", { name: /^Mittente/ }).evaluate(e => e.selectedOptions[0]?.textContent), "status:", (await p.locator("[role=status]").allTextContents()).filter(Boolean), "focus:", await p.evaluate(() => document.activeElement?.outerHTML.slice(0, 90)));
// correction: remove rule tag from eml2
await s.fill("lampone"); await p.waitForTimeout(2500);
await p.locator("article", { hasText: "j2eml2" }).getByRole("button", { name: /Avviso TARI/ }).click();
d = p.getByRole("dialog"); await d.waitFor(); await p.waitForTimeout(1500);
const tagBox = d.getByRole("checkbox", { name: new RegExp(tag) });
console.log("eml2 tag checked:", await tagBox.isChecked(), "labeltext:", await tagBox.evaluate(e => e.closest("label")?.innerText));
await tagBox.uncheck();
await d.getByRole("button", { name: "Salva modifiche" }).click(); await p.waitForTimeout(1500);
const det = await (await p.request.get(`http://localhost:18080/api/documents/${eml2}`)).json();
console.log("eml2 tags after correction:", JSON.stringify(det.tags));

// retrieval
for (const q of [`sender:"Comune di Esempio J2 ${stamp}"`, `tag:"${tag}"`, "date:2026-04-15", "RIPIANO JUDGE", "tari lampone", "lampone 2026 avviso"]) {
  await s.fill(q); await p.waitForTimeout(2500);
  console.log("Q", q, "=>", JSON.stringify(await rows()), (await p.locator("main .inline-error").allInnerTexts()).join("|"));
}
await s.fill(""); await p.waitForTimeout(1500);
await p.getByRole("button", { name: "Filtri" }).click(); await p.waitForTimeout(800);
save("filters.yml", await p.locator("main").ariaSnapshot());
await p.screenshot({ path: ART + "/mobile-filters.png", fullPage: false });

// physical
await nav("Archivio cartaceo");
await p.getByPlaceholder("es. Schedario").fill(`Scaffale J2 ${stamp}`);
await p.getByRole("button", { name: "Aggiungi posizione" }).click(); await p.waitForTimeout(1200);
await p.getByPlaceholder("es. Schedario").fill(`Scatola J2 ${stamp}`);
await p.getByRole("combobox", { name: /Dentro/ }).selectOption({ label: `Scaffale J2 ${stamp}` }).catch(e => console.log("inside select fail", e.message.slice(0, 200)));
await p.getByRole("button", { name: "Aggiungi posizione" }).click(); await p.waitForTimeout(1200);
save("physical.yml", await p.locator("main").ariaSnapshot());
console.log(await audit(p));
await nav("Tutti i documenti");
await s.fill("j2cam"); await p.waitForTimeout(2000);
await p.getByRole("button", { name: /^j2cam-/ }).click();
d = p.getByRole("dialog"); await d.waitFor(); await p.waitForTimeout(1500);
await d.getByRole("combobox", { name: "Posizione della nuova copia cartacea" }).selectOption({ label: `Scaffale J2 ${stamp}` }).catch(async (e) => { console.log("opts:", await d.getByRole("combobox", { name: "Posizione della nuova copia cartacea" }).evaluate(el => [...el.options].map(o => o.textContent))); });
await d.getByRole("button", { name: "Crea adesivo" }).click(); await p.waitForTimeout(1500);
const copy = await d.locator(".copy-card").first();
const code = (await copy.locator("strong").first().textContent()).trim();
console.log("sticker", code);
save("copy-card.yml", await copy.ariaSnapshot());
await copy.screenshot({ path: ART + "/mobile-copy-card.png" });
save("ids2.json", { code, stamp });
await b.close();

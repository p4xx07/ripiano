import fs from "node:fs";
import { judge, Client, BASE, mcp, tool } from "./lib.mjs";
const c = await judge(); const o = JSON.parse(fs.readFileSync("s2-out.json"));
let r = await tool(o.gC.token, "search_documents", { query: "conversion verification" }); console.log("C (no text scope) search OCR phrase:", r.r.documents?.length);
r = await tool(o.gC.token, "search_documents", { query: "lampone" }); console.log("C search 'lampone' (title word):", r.r.documents?.map(d => d.title), "keys:", Object.keys(r.r.documents?.[0] || {}));
r = await tool(o.gB.token, "search_documents", { query: "conversion verification" }); console.log("B (no text) OCR phrase:", r.r.documents?.length);
let a = await c.raw("GET", "/admin/"); console.log("admin as judge3:", a.status, a.headers.get("location")); const at = await a.text(); console.log("  admin models:", [...at.matchAll(/class="model-(\w+)/g)].map(m => m[1]).join(","), at.length);
a = await c.raw("GET", "/api/documents", undefined, { "X-Forwarded-For": "1.2.3.4", "X-Real-IP": "9.9.9.9" }); console.log("xff ok", a.status);
for (const p of ["/", "/api/session", "/mcp", "/sw.js", "/manifest.webmanifest", "/index.html", "/.env", "/api/../.git/config", "/media/originals/", "/static/"]) { const x = await fetch(BASE + p, { redirect: "manual" }); console.log(p.padEnd(26), x.status, "| cc:", x.headers.get("cache-control"), "| csp:", (x.headers.get("content-security-policy") || "").slice(0, 30), "| xcto:", x.headers.get("x-content-type-options"), "| hsts:", x.headers.get("strict-transport-security"), "| server:", x.headers.get("server")); }
// audit entries for C and events count
r = await c.j("GET", "/api/agents/events"); console.log("events cap:", r.d.events.length);
// 2 grants same name blocked? expired param
r = await c.j("POST", "/api/agents", { name: "j3x", scopes: ["documents:search", "admin:all"] }); console.log("bogus scope", r.s, r.d.error);
r = await c.j("POST", "/api/agents", { name: "j3x", scopes: ["documents:search"], expires_in_days: 99999 }); console.log("long expiry", r.s, r.d.error);
// cleanup: revoke remaining j3r3/j3b grants at the very end is done later

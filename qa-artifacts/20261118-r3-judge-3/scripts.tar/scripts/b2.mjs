import { open, signIn, nav, shot } from "./blib.mjs";
import { FIX } from "./lib.mjs";
import fs from "node:fs";
const { browser, page, errors, context } = await open(false);
await signIn(page);
const stamp = Date.now() % 1000000;
const t0 = Date.now();
await page.getByRole("button", { name: "Add document", exact: true }).click();
await page.waitForTimeout(500);
await shot(page, "d-03-add-dialog");
console.log("ADD DIALOG TEXT:", (await page.getByRole("dialog").innerText()).replace(/\n+/g, " | ").slice(0, 900));
const chooser = page.waitForEvent("filechooser");
await page.getByRole("button", { name: /Browse files/ }).click();
const files = ["three-pages.pdf", "judge.png", "office-letter.docx", "email-notice.eml", "outlook-notice.msg", "office-sheet.xlsx"].map(f => ({ name: `j3b-${stamp}-${f}`, mimeType: "application/octet-stream", buffer: fs.readFileSync(FIX + f) }));
files.push({ name: `j3b-${stamp}-bad.txt`, mimeType: "text/plain", buffer: Buffer.from("not a doc") });
await (await chooser).setFiles(files);
await page.waitForTimeout(4000);
await shot(page, "d-04-after-upload");
console.log("AFTER UPLOAD dialogs:", await page.getByRole("dialog").count());
console.log("PAGE STATUS TEXT:", (await page.locator("main").innerText()).replace(/\n+/g, " | ").slice(0, 1500));
// wait until processing done
for (let i = 0; i < 40; i++) { const t = await page.locator("main").innerText(); if (!/Reading|Waiting|Processing|In progress/i.test(t.slice(0, 3000))) break; await page.waitForTimeout(1500); }
console.log("processing visible done after", Date.now() - t0, "ms");
await shot(page, "d-05-processed");
// search
const search = page.getByRole("searchbox").or(page.getByPlaceholder(/Search/)).first();
await search.fill("conversion verification"); await page.waitForTimeout(1200);
await shot(page, "d-06-search-ocr");
console.log("SEARCH RESULT:", (await page.locator("main").innerText()).split("Select documents")[1]?.replace(/\n+/g, " | ").slice(0, 600));
fs.writeFileSync("/private/tmp/claude-501/-Users-debotta-dbrepos-ripiano/23569b07-51e7-4ab9-89ce-c4e342f5998a/scratchpad/judge3/b2-stamp.txt", String(stamp));
console.log("errors", errors);
await browser.close();

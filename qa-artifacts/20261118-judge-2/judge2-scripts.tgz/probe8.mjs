import { launch, login, MOBILE, ART } from "./common.mjs";
const b = await launch(); const p = await (await b.newContext({ ...MOBILE, viewport: { width: 390, height: 844 } })).newPage();
await login(p, "it");
await p.getByRole("button", { name: "Apri o chiudi il menu" }).click(); await p.waitForTimeout(600);
const side = await p.evaluate(() => { const s = document.querySelector(".sidebar"); const cs = getComputedStyle(s); return { pos: cs.position, h: cs.height, ov: cs.overflowY, top: s.getBoundingClientRect().top }; });
console.log(side);
await p.mouse.move(150, 500); await p.mouse.wheel(0, 800); await p.waitForTimeout(500);
// touch swipe via CDP
const c = await p.context().newCDPSession(p);
await c.send("Input.synthesizeScrollGesture", { x: 150, y: 550, yDistance: -600, speed: 800 }); await p.waitForTimeout(800);
const check = await p.evaluate(() => [...document.querySelectorAll(".sidebar .nav-link, .sidebar select, .sidebar button")].map(b2 => { const r = b2.getBoundingClientRect(); const e = document.elementFromPoint(Math.max(1, r.left + 5), Math.min(r.top + r.height / 2, 9999)); return (b2.getAttribute("aria-label") || b2.textContent.trim()).slice(0, 20) + ":" + Math.round(r.top) + (e && (e === b2 || b2.contains(e)) ? " ok" : " UNREACHABLE"); }));
console.log(check.join("\n"));
await p.screenshot({ path: ART + "/mobile390-menu-after-scroll.png" });
await b.close();
